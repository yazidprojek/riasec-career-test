// Real-time data management utilities
export interface User {
  id: string
  name: string
  email: string
  role: "siswa" | "guru" | "admin"
  school?: string
  dateOfBirth?: string
  phone?: string
  registrationDate: string
  lastActive: string
  approved?: boolean
}

export interface TestResult {
  id: string
  userId: string
  userName: string
  userSchool: string
  date: string
  scores: {
    R: number
    I: number
    A: number
    S: number
    E: number
    C: number
  }
  dominantTypes: string[]
  bagian1: { [key: string]: number }
  bagian2: { [key: string]: number }
  bagian3: { [key: string]: number }
}

export interface Teacher extends User {
  status: "pending" | "approved" | "rejected"
  subscriptionEnd?: string
  approvedDate?: string
}

export interface Testimonial {
  id: string
  name: string
  role: string
  school: string
  content: string
  rating: number
  isActive: boolean
  createdAt: string
}

export interface CareerSuggestion {
  id: string
  type: "R" | "I" | "A" | "S" | "E" | "C"
  career: string
  description: string
  matchPercentage: number
  isActive: boolean
}

// Get all users from localStorage
export const getAllUsers = (): User[] => {
  const users = localStorage.getItem("allUsers")
  return users ? JSON.parse(users) : []
}

// Get all teachers from localStorage
export const getAllTeachers = (): Teacher[] => {
  const teachers = localStorage.getItem("allTeachers")
  return teachers ? JSON.parse(teachers) : []
}

// Get all test results from localStorage
export const getAllTestResults = (): TestResult[] => {
  const results = localStorage.getItem("allTestResults")
  return results ? JSON.parse(results) : []
}

// Get all testimonials
export const getAllTestimonials = (): Testimonial[] => {
  const testimonials = localStorage.getItem("testimonials")
  return testimonials ? JSON.parse(testimonials) : getDefaultTestimonials()
}

// Default testimonials (sync with homepage)
const getDefaultTestimonials = (): Testimonial[] => {
  return [
    {
      id: "testimonial-1",
      name: "Andi Pratama",
      role: "Siswa SMA Negeri 1",
      school: "SMA Negeri 1 Pekanbaru",
      content:
        "Tes ini benar-benar membantu saya memahami minat saya. Sekarang saya yakin ingin kuliah di jurusan Psikologi!",
      rating: 5,
      isActive: true,
      createdAt: "2024-01-15T10:00:00.000Z",
    },
    {
      id: "testimonial-2",
      name: "Siti Nurhaliza, S.Pd",
      role: "Guru BK SMA Negeri 2",
      school: "SMA Negeri 2 Pekanbaru",
      content:
        "Platform ini sangat membantu dalam memberikan bimbingan karier kepada siswa. Data yang dihasilkan sangat akurat dan detail.",
      rating: 5,
      isActive: true,
      createdAt: "2024-01-16T11:00:00.000Z",
    },
    {
      id: "testimonial-3",
      name: "Rizki Maulana",
      role: "Mahasiswa Teknik",
      school: "Universitas Riau",
      content:
        "Hasil tesnya sangat membantu saya memilih jurusan. Ternyata saya cocok di bidang teknik, dan sekarang saya kuliah Teknik Informatika!",
      rating: 5,
      isActive: true,
      createdAt: "2024-01-17T12:00:00.000Z",
    },
  ]
}

// Get all career suggestions
export const getAllCareerSuggestions = (): CareerSuggestion[] => {
  const suggestions = localStorage.getItem("careerSuggestions")
  return suggestions ? JSON.parse(suggestions) : getDefaultCareerSuggestions()
}

// Default career suggestions
const getDefaultCareerSuggestions = (): CareerSuggestion[] => {
  return [
    // Realistic
    {
      id: "r1",
      type: "R",
      career: "Teknisi Komputer",
      description: "Ahli dalam perbaikan dan maintenance komputer",
      matchPercentage: 95,
      isActive: true,
    },
    {
      id: "r2",
      type: "R",
      career: "Montir",
      description: "Spesialis perbaikan kendaraan bermotor",
      matchPercentage: 90,
      isActive: true,
    },
    {
      id: "r3",
      type: "R",
      career: "Pilot",
      description: "Penerbang pesawat komersial atau militer",
      matchPercentage: 88,
      isActive: true,
    },
    {
      id: "r4",
      type: "R",
      career: "Ahli Listrik",
      description: "Teknisi instalasi dan perbaikan listrik",
      matchPercentage: 92,
      isActive: true,
    },
    {
      id: "r5",
      type: "R",
      career: "Arsitek",
      description: "Perancang bangunan dan struktur",
      matchPercentage: 85,
      isActive: true,
    },

    // Investigative
    {
      id: "i1",
      type: "I",
      career: "Ilmuwan",
      description: "Peneliti di berbagai bidang sains",
      matchPercentage: 96,
      isActive: true,
    },
    {
      id: "i2",
      type: "I",
      career: "Dokter",
      description: "Praktisi medis dan kesehatan",
      matchPercentage: 94,
      isActive: true,
    },
    {
      id: "i3",
      type: "I",
      career: "Psikolog",
      description: "Ahli dalam perilaku dan mental manusia",
      matchPercentage: 91,
      isActive: true,
    },
    {
      id: "i4",
      type: "I",
      career: "Analis Data",
      description: "Spesialis analisis dan interpretasi data",
      matchPercentage: 89,
      isActive: true,
    },
    {
      id: "i5",
      type: "I",
      career: "Software Engineer",
      description: "Pengembang perangkat lunak",
      matchPercentage: 87,
      isActive: true,
    },

    // Artistic
    {
      id: "a1",
      type: "A",
      career: "Desainer Grafis",
      description: "Perancang visual dan komunikasi",
      matchPercentage: 93,
      isActive: true,
    },
    {
      id: "a2",
      type: "A",
      career: "Musisi",
      description: "Seniman musik dan komposer",
      matchPercentage: 91,
      isActive: true,
    },
    {
      id: "a3",
      type: "A",
      career: "Penulis",
      description: "Pencipta karya tulis dan sastra",
      matchPercentage: 89,
      isActive: true,
    },
    {
      id: "a4",
      type: "A",
      career: "Animator",
      description: "Pembuat animasi dan motion graphics",
      matchPercentage: 88,
      isActive: true,
    },
    {
      id: "a5",
      type: "A",
      career: "Fashion Designer",
      description: "Perancang busana dan mode",
      matchPercentage: 86,
      isActive: true,
    },

    // Social
    { id: "s1", type: "S", career: "Guru", description: "Pendidik dan pengajar", matchPercentage: 95, isActive: true },
    {
      id: "s2",
      type: "S",
      career: "Perawat",
      description: "Tenaga kesehatan dan perawatan",
      matchPercentage: 93,
      isActive: true,
    },
    {
      id: "s3",
      type: "S",
      career: "Konselor",
      description: "Pembimbing dan penasihat",
      matchPercentage: 91,
      isActive: true,
    },
    {
      id: "s4",
      type: "S",
      career: "Social Worker",
      description: "Pekerja sosial dan kemasyarakatan",
      matchPercentage: 89,
      isActive: true,
    },
    {
      id: "s5",
      type: "S",
      career: "HR Specialist",
      description: "Ahli sumber daya manusia",
      matchPercentage: 87,
      isActive: true,
    },

    // Enterprising
    {
      id: "e1",
      type: "E",
      career: "Pengusaha",
      description: "Pemilik dan pengelola bisnis",
      matchPercentage: 94,
      isActive: true,
    },
    {
      id: "e2",
      type: "E",
      career: "Sales Manager",
      description: "Manajer penjualan dan pemasaran",
      matchPercentage: 92,
      isActive: true,
    },
    {
      id: "e3",
      type: "E",
      career: "Marketing Director",
      description: "Direktur pemasaran dan branding",
      matchPercentage: 90,
      isActive: true,
    },
    {
      id: "e4",
      type: "E",
      career: "Business Consultant",
      description: "Konsultan bisnis dan strategi",
      matchPercentage: 88,
      isActive: true,
    },
    {
      id: "e5",
      type: "E",
      career: "Lawyer",
      description: "Ahli hukum dan advokat",
      matchPercentage: 86,
      isActive: true,
    },

    // Conventional
    {
      id: "c1",
      type: "C",
      career: "Akuntan",
      description: "Ahli keuangan dan akuntansi",
      matchPercentage: 95,
      isActive: true,
    },
    {
      id: "c2",
      type: "C",
      career: "Admin Kantor",
      description: "Pengelola administrasi perkantoran",
      matchPercentage: 90,
      isActive: true,
    },
    {
      id: "c3",
      type: "C",
      career: "Bank Teller",
      description: "Petugas layanan perbankan",
      matchPercentage: 88,
      isActive: true,
    },
    {
      id: "c4",
      type: "C",
      career: "Auditor",
      description: "Pemeriksa keuangan dan sistem",
      matchPercentage: 92,
      isActive: true,
    },
    {
      id: "c5",
      type: "C",
      career: "Quality Control",
      description: "Pengawas kualitas produk",
      matchPercentage: 87,
      isActive: true,
    },
  ]
}

// Save user data
export const saveUser = (user: User) => {
  const users = getAllUsers()
  const existingIndex = users.findIndex((u) => u.id === user.id)

  if (existingIndex >= 0) {
    users[existingIndex] = user
  } else {
    users.push(user)
  }

  localStorage.setItem("allUsers", JSON.stringify(users))
}

// Save teacher data
export const saveTeacher = (teacher: Teacher) => {
  const teachers = getAllTeachers()
  const existingIndex = teachers.findIndex((t) => t.id === teacher.id)

  if (existingIndex >= 0) {
    teachers[existingIndex] = teacher
  } else {
    teachers.push(teacher)
  }

  localStorage.setItem("allTeachers", JSON.stringify(teachers))
}

// Save test result
export const saveTestResult = (result: TestResult) => {
  const results = getAllTestResults()
  const existingIndex = results.findIndex((r) => r.id === result.id)

  if (existingIndex >= 0) {
    results[existingIndex] = result
  } else {
    results.push(result)
  }

  localStorage.setItem("allTestResults", JSON.stringify(results))
}

// Save testimonial
export const saveTestimonial = (testimonial: Testimonial) => {
  const testimonials = getAllTestimonials()
  const existingIndex = testimonials.findIndex((t) => t.id === testimonial.id)

  if (existingIndex >= 0) {
    testimonials[existingIndex] = testimonial
  } else {
    testimonials.push(testimonial)
  }

  localStorage.setItem("testimonials", JSON.stringify(testimonials))
}

// Save career suggestion
export const saveCareerSuggestion = (suggestion: CareerSuggestion) => {
  const suggestions = getAllCareerSuggestions()
  const existingIndex = suggestions.findIndex((s) => s.id === suggestion.id)

  if (existingIndex >= 0) {
    suggestions[existingIndex] = suggestion
  } else {
    suggestions.push(suggestion)
  }

  localStorage.setItem("careerSuggestions", JSON.stringify(suggestions))
}

// Get users by school
export const getUsersBySchool = (school: string): User[] => {
  return getAllUsers().filter((user) => user.school === school && user.role === "siswa")
}

// Get test results by school
export const getTestResultsBySchool = (school: string): TestResult[] => {
  return getAllTestResults().filter((result) => result.userSchool === school)
}

// Delete user
export const deleteUser = (userId: string) => {
  const users = getAllUsers().filter((user) => user.id !== userId)
  localStorage.setItem("allUsers", JSON.stringify(users))

  // Also delete test results for this user
  const results = getAllTestResults().filter((result) => result.userId !== userId)
  localStorage.setItem("allTestResults", JSON.stringify(results))
}

// Delete teacher
export const deleteTeacher = (teacherId: string) => {
  const teachers = getAllTeachers().filter((teacher) => teacher.id !== teacherId)
  localStorage.setItem("allTeachers", JSON.stringify(teachers))
}

// Delete testimonial
export const deleteTestimonial = (testimonialId: string) => {
  const testimonials = getAllTestimonials().filter((t) => t.id !== testimonialId)
  localStorage.setItem("testimonials", JSON.stringify(testimonials))
}

// Delete career suggestion
export const deleteCareerSuggestion = (suggestionId: string) => {
  const suggestions = getAllCareerSuggestions().filter((s) => s.id !== suggestionId)
  localStorage.setItem("careerSuggestions", JSON.stringify(suggestions))
}

// Update teacher status
export const updateTeacherStatus = (teacherId: string, status: "approved" | "rejected") => {
  const teachers = getAllTeachers()
  const teacherIndex = teachers.findIndex((t) => t.id === teacherId)

  if (teacherIndex >= 0) {
    teachers[teacherIndex].status = status
    if (status === "approved") {
      // Set subscription end date to 1 year from now
      const subscriptionEnd = new Date()
      subscriptionEnd.setFullYear(subscriptionEnd.getFullYear() + 1)
      teachers[teacherIndex].subscriptionEnd = subscriptionEnd.toISOString()
      teachers[teacherIndex].approvedDate = new Date().toISOString()
    }
    localStorage.setItem("allTeachers", JSON.stringify(teachers))
  }
}

// Initialize super admin
export const initializeSuperAdmin = () => {
  const superAdmin: User = {
    id: "super-admin",
    name: "Super Admin MGBK",
    email: "admin@mgbkpekanbaru.com",
    role: "admin",
    registrationDate: new Date().toISOString(),
    lastActive: new Date().toISOString(),
  }

  const users = getAllUsers()
  const existingSuperAdmin = users.find((u) => u.id === "super-admin")

  if (!existingSuperAdmin) {
    users.push(superAdmin)
    localStorage.setItem("allUsers", JSON.stringify(users))
  }
}

// Initialize demo data
export const initializeDemoData = () => {
  // Demo students
  const demoStudents: User[] = [
    {
      id: "demo-student-1",
      name: "Ahmad Rizki",
      email: "ahmad.rizki@demo.com",
      role: "siswa",
      school: "SMA Negeri 1 Pekanbaru",
      dateOfBirth: "2005-03-15",
      phone: "081234567890",
      registrationDate: "2024-01-15T10:00:00.000Z",
      lastActive: new Date().toISOString(),
    },
    {
      id: "demo-student-2",
      name: "Siti Nurhaliza",
      email: "siti.nur@demo.com",
      role: "siswa",
      school: "SMA Negeri 1 Pekanbaru",
      dateOfBirth: "2005-07-22",
      phone: "081234567891",
      registrationDate: "2024-01-16T11:00:00.000Z",
      lastActive: new Date().toISOString(),
    },
    {
      id: "demo-student-3",
      name: "Budi Santoso",
      email: "budi.santoso@demo.com",
      role: "siswa",
      school: "SMA Negeri 2 Pekanbaru",
      dateOfBirth: "2005-11-08",
      phone: "081234567892",
      registrationDate: "2024-01-17T09:00:00.000Z",
      lastActive: new Date().toISOString(),
    },
  ]

  // Demo teachers
  const demoTeachers: Teacher[] = [
    {
      id: "demo-teacher-1",
      name: "Dr. Sarah Johnson",
      email: "sarah.johnson@demo.com",
      role: "guru",
      school: "SMA Negeri 1 Pekanbaru",
      phone: "081234567893",
      registrationDate: "2024-01-10T08:00:00.000Z",
      lastActive: new Date().toISOString(),
      status: "approved",
      subscriptionEnd: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(),
      approvedDate: "2024-01-10T08:00:00.000Z",
    },
    {
      id: "demo-teacher-2",
      name: "Ahmad Hidayat, S.Pd",
      email: "ahmad.hidayat@demo.com",
      role: "guru",
      school: "SMA Negeri 2 Pekanbaru",
      phone: "081234567894",
      registrationDate: "2024-01-12T10:00:00.000Z",
      lastActive: new Date().toISOString(),
      status: "approved",
      subscriptionEnd: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(),
      approvedDate: "2024-01-12T10:00:00.000Z",
    },
  ]

  // Demo test results
  const demoTestResults: TestResult[] = [
    {
      id: "demo-result-1",
      userId: "demo-student-1",
      userName: "Ahmad Rizki",
      userSchool: "SMA Negeri 1 Pekanbaru",
      date: "2024-01-20T14:00:00.000Z",
      scores: { R: 8, I: 12, A: 18, S: 22, E: 20, C: 14 },
      dominantTypes: ["S", "E", "A"],
      bagian1: {},
      bagian2: {},
      bagian3: {},
    },
    {
      id: "demo-result-2",
      userId: "demo-student-2",
      userName: "Siti Nurhaliza",
      userSchool: "SMA Negeri 1 Pekanbaru",
      date: "2024-01-21T15:00:00.000Z",
      scores: { R: 16, I: 24, A: 10, S: 12, E: 8, C: 20 },
      dominantTypes: ["I", "C", "R"],
      bagian1: {},
      bagian2: {},
      bagian3: {},
    },
  ]

  // Save demo data
  const existingUsers = getAllUsers()
  const existingTeachers = getAllTeachers()
  const existingResults = getAllTestResults()

  // Only add demo data if it doesn't exist
  demoStudents.forEach((student) => {
    if (!existingUsers.find((u) => u.id === student.id)) {
      saveUser(student)
    }
  })

  demoTeachers.forEach((teacher) => {
    if (!existingTeachers.find((t) => t.id === teacher.id)) {
      saveTeacher(teacher)
    }
  })

  demoTestResults.forEach((result) => {
    if (!existingResults.find((r) => r.id === result.id)) {
      saveTestResult(result)
    }
  })

  // Initialize default testimonials if not exist
  const existingTestimonials = localStorage.getItem("testimonials")
  if (!existingTestimonials) {
    localStorage.setItem("testimonials", JSON.stringify(getDefaultTestimonials()))
  }
}

// Export to CSV
export const exportToCSV = (data: any[], filename: string) => {
  if (data.length === 0) return

  const headers = Object.keys(data[0])
  const csvContent = [
    headers.join(","),
    ...data.map((row) => headers.map((header) => `"${row[header] || ""}"`).join(",")),
  ].join("\n")

  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
  const link = document.createElement("a")
  const url = URL.createObjectURL(blob)
  link.setAttribute("href", url)
  link.setAttribute("download", filename)
  link.style.visibility = "hidden"
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
}

// Generate CSV template for questions
export const generateQuestionTemplate = () => {
  const template = [
    { bagian: 1, type: "R", text: "Contoh pertanyaan Realistic", isActive: true },
    { bagian: 1, type: "I", text: "Contoh pertanyaan Investigative", isActive: true },
    { bagian: 1, type: "A", text: "Contoh pertanyaan Artistic", isActive: true },
    { bagian: 1, type: "S", text: "Contoh pertanyaan Social", isActive: true },
    { bagian: 1, type: "E", text: "Contoh pertanyaan Enterprising", isActive: true },
    { bagian: 1, type: "C", text: "Contoh pertanyaan Conventional", isActive: true },
  ]

  exportToCSV(template, "template_pertanyaan_riasec.csv")
}

// Check teacher subscription
export const isTeacherSubscriptionActive = (teacher: Teacher): boolean => {
  if (!teacher.subscriptionEnd) return false
  return new Date(teacher.subscriptionEnd) > new Date()
}

// Get teacher subscription status
export const getTeacherSubscriptionStatus = (teacher: Teacher): "active" | "warning" | "expired" => {
  if (!teacher.subscriptionEnd) return "expired"

  const now = new Date()
  const endDate = new Date(teacher.subscriptionEnd)
  const daysLeft = Math.ceil((endDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))

  if (daysLeft <= 0) return "expired"
  if (daysLeft <= 30) return "warning"
  return "active"
}

// Get days remaining for teacher subscription
export const getTeacherDaysRemaining = (teacher: Teacher): number => {
  if (!teacher.subscriptionEnd) return 0

  const now = new Date()
  const endDate = new Date(teacher.subscriptionEnd)
  const daysLeft = Math.ceil((endDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))

  return Math.max(0, daysLeft)
}
