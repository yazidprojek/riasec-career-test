"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Clock, Trophy, FileText, LogOut, User, Download, History } from "lucide-react"
import Link from "next/link"
import { getAllTestResults, type TestResult } from "@/utils/dataManager"
import jsPDF from "jspdf"

export default function SiswaDashboard() {
  const [user, setUser] = useState<any>(null)
  const [testResult, setTestResult] = useState<TestResult | null>(null)
  const [testHistory, setTestHistory] = useState<TestResult[]>([])
  const [testProgress, setTestProgress] = useState({
    bagian1: 0,
    bagian2: 0,
    bagian3: 0,
  })
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      const parsed = JSON.parse(userData)
      setUser(parsed)

      // Get user's test results
      const allResults = getAllTestResults()
      const userResults = allResults.filter((r) => r.userId === parsed.id)
      setTestHistory(userResults)
      setTestResult(userResults.length > 0 ? userResults[0] : null)

      // Get test progress from localStorage
      const bagian1Results = localStorage.getItem("bagian1Results")
      const bagian2Results = localStorage.getItem("bagian2Results")
      const bagian3Results = localStorage.getItem("bagian3Results")

      setTestProgress({
        bagian1: bagian1Results ? 100 : 0,
        bagian2: bagian2Results ? 100 : 0,
        bagian3: bagian3Results ? 100 : 0,
      })
    } else {
      router.push("/login")
    }
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("user")
    router.push("/")
  }

  const downloadResultPDF = async (result?: TestResult) => {
    const resultToDownload = result || testResult
    if (!resultToDownload) return

    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: [210, 330] // F4 size
    })

    // Set margins (3,3,4,4)
    const leftMargin = 3
    const rightMargin = 3
    const topMargin = 4
    const bottomMargin = 4
    const pageWidth = 210
    const pageHeight = 330

    // Header
    pdf.setFontSize(20)
    pdf.text("Hasil Tes RIASEC", leftMargin, topMargin + 15)

    // Student info
    pdf.setFontSize(12)
    pdf.text(`Nama: ${user.fullName || user.name}`, leftMargin, topMargin + 35)
    pdf.text(`Email: ${user.email}`, leftMargin, topMargin + 45)
    pdf.text(`Sekolah: ${user.school || "Tidak diisi"}`, leftMargin, topMargin + 55)
    pdf.text(`Tanggal Tes: ${new Date(resultToDownload.date).toLocaleDateString("id-ID")}`, leftMargin, topMargin + 65)

    // Scores
    pdf.text("Skor RIASEC:", leftMargin, topMargin + 85)
    let yPos = topMargin + 95
    Object.entries(resultToDownload.scores).forEach(([type, score]) => {
      pdf.text(`${type}: ${score}`, leftMargin + 10, yPos)
      yPos += 10
    })

    // Dominant types
    pdf.text("Tipe Dominan:", leftMargin, yPos + 10)
    resultToDownload.dominantTypes.forEach((type, index) => {
      pdf.text(`${index + 1}. ${type}`, leftMargin + 10, yPos + 20 + index * 10)
    })

    // Footer
    pdf.setFontSize(10)
    pdf.text("Copyright © mgbkpekanbaru", pageWidth / 2, pageHeight - bottomMargin, { align: "center" })

    pdf.save(`hasil_tes_riasec_${user.name?.replace(/\s+/g, "_")}_${new Date(resultToDownload.date).toISOString().split('T')[0]}.pdf`)
  }

  if (!user) return <div>Loading...</div>

  const hasCompletedTest = testResult !== null
  const totalProgress = (testProgress.bagian1 + testProgress.bagian2 + testProgress.bagian3) / 3

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
                <User className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-semibold text-gray-900">Dashboard Siswa</h1>
                <p className="text-sm text-gray-500">Selamat datang, {user.fullName || user.name}</p>
              </div>
            </div>
            <Button variant="outline" onClick={handleLogout} className="flex items-center space-x-2 bg-transparent">
              <LogOut className="w-4 h-4" />
              <span>Keluar</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Halo, {user.fullName || user.name}! 👋</h2>
          <p className="text-gray-600">
            {hasCompletedTest
              ? "Kamu sudah menyelesaikan tes RIASEC. Lihat hasilnya di bawah!"
              : "Siap untuk menemukan minat kariermu? Mulai tes RIASEC sekarang!"}
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="border-0 shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                  <BookOpen className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{testHistory.length}</p>
                  <p className="text-sm text-gray-600">Tes Selesai</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                  <Trophy className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{hasCompletedTest ? "3" : "0"}</p>
                  <p className="text-sm text-gray-600">Tipe Dominan</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                  <Clock className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">196</p>
                  <p className="text-sm text-gray-600">Total Pertanyaan</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
                  <FileText className="w-6 h-6 text-orange-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{Math.round(totalProgress)}%</p>
                  <p className="text-sm text-gray-600">Progress Tes</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {!hasCompletedTest ? (
              /* Test Start Card */
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl">Mulai Tes RIASEC</CardTitle>
                  <CardDescription>
                    Tes ini terdiri dari 3 bagian dengan total 196 pertanyaan untuk mengidentifikasi minat kariermu
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid md:grid-cols-3 gap-4">
                      <div className="p-4 bg-blue-50 rounded-xl">
                        <h4 className="font-semibold text-blue-900">Bagian I</h4>
                        <p className="text-sm text-blue-700">60 pertanyaan</p>
                        <p className="text-xs text-blue-600">Setuju / Tidak Setuju</p>
                        <div className="mt-2">
                          <Progress value={testProgress.bagian1} className="h-2" />
                          <p className="text-xs text-blue-600 mt-1">{testProgress.bagian1}% selesai</p>
                        </div>
                      </div>
                      <div className="p-4 bg-green-50 rounded-xl">
                        <h4 className="font-semibold text-green-900">Bagian II</h4>
                        <p className="text-sm text-green-700">66 pertanyaan</p>
                        <p className="text-xs text-green-600">Ya / Tidak</p>
                        <div className="mt-2">
                          <Progress value={testProgress.bagian2} className="h-2" />
                          <p className="text-xs text-green-600 mt-1">{testProgress.bagian2}% selesai</p>
                        </div>
                      </div>
                      <div className="p-4 bg-purple-50 rounded-xl">
                        <h4 className="font-semibold text-purple-900">Bagian III</h4>
                        <p className="text-sm text-purple-700">70 pertanyaan</p>
                        <p className="text-xs text-purple-600">Ya / Tidak</p>
                        <div className="mt-2">
                          <Progress value={testProgress.bagian3} className="h-2" />
                          <p className="text-xs text-purple-600 mt-1">{testProgress.bagian3}% selesai</p>
                        </div>
                      </div>
                    </div>

                    <div className="bg-yellow-50 p-4 rounded-xl">
                      <h4 className="font-semibold text-yellow-900 mb-2">Tips Mengerjakan:</h4>
                      <ul className="text-sm text-yellow-800 space-y-1">
                        <li>• Jawab dengan jujur sesuai minat dan kepribadianmu</li>
                        <li>• Tidak ada jawaban benar atau salah</li>
                        <li>• Estimasi waktu: 20-30 menit</li>
                        <li>• Pastikan koneksi internet stabil</li>
                      </ul>
                    </div>

                    <Link href="/test/bagian-1">
                      <Button
                        size="lg"
                        className="w-full rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                      >
                        {testProgress.bagian1 > 0 ? "Lanjutkan Tes" : "Mulai Tes Sekarang"}
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ) : (
              /* Test Results Card */
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl flex items-center space-x-2">
                    <Trophy className="w-6 h-6 text-yellow-500" />
                    <span>Hasil Tes RIASEC Terbaru</span>
                  </CardTitle>
                  <CardDescription>
                    Tes diselesaikan pada {new Date(testResult.date).toLocaleDateString("id-ID")}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold mb-3">Tipe Dominan Kamu:</h4>
                      <div className="flex flex-wrap gap-2">
                        {testResult.dominantTypes.slice(0, 3).map((type, index) => (
                          <Badge key={type} variant="secondary" className="px-3 py-1">
                            #{index + 1} {type}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="grid md:grid-cols-3 gap-4">
                      <Link href="/dashboard/siswa/results">
                        <Button variant="outline" className="w-full bg-transparent">
                          Lihat Hasil Detail
                        </Button>
                      </Link>
                      <Button className="w-full" onClick={() => downloadResultPDF()}>
                        <Download className="w-4 h-4 mr-2" />
                        Download PDF
                      </Button>
                      <Button variant="outline" className="w-full bg-transparent" onClick={() => router.push("#history")}>
                        <History className="w-4 h-4 mr-2" />
                        Lihat Histori
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Test History */}
            {testHistory.length > 0 && (
              <Card className="border-0 shadow-lg" id="history">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <History className="w-6 h-6 text-blue-500" />
                    <span>Histori Tes</span>
                  </CardTitle>
                  <CardDescription>Riwayat semua tes yang pernah kamu kerjakan</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {testHistory.map((result, index) => (
                      <div key={result.id} className="p-4 border rounded-lg hover:bg-gray-50">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-2">
                              <Badge variant={index === 0 ? "default" : "secondary"}>
                                {index === 0 ? "Terbaru" : `Tes #${testHistory.length - index}`}
                              </Badge>
                              <span className="text-sm text-gray-600">
                                {new Date(result.date).toLocaleDateString("id-ID")}
                              </span>
                            </div>
                            <div className="flex flex-wrap gap-1 mb-2">
                              {result.dominantTypes.slice(0, 3).map((type, typeIndex) => (
                                <Badge key={type} variant="outline" className="text-xs">
                                  #{typeIndex + 1} {type}
                                </Badge>
                              ))}
                            </div>
                            <div className="text-sm text-gray-600">
                              Skor: R:{result.scores.R} I:{result.scores.I} A:{result.scores.A} S:{result.scores.S} E:{result.scores.E} C:{result.scores.C}
                            </div>
                          </div>
                          <div className="flex space-x-2 ml-4">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => downloadResultPDF(result)}
                            >
                              <Download className="w-4 h-4" />
                            </Button>
                            <Link href="/dashboard/siswa/results">
                              <Button variant="outline" size="sm">
                                <FileText className="w-4 h-4" />
                              </Button>
                            </Link>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>\
