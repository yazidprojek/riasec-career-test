"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Shield, ArrowLeft } from "lucide-react"
import Link from "next/link"
import { initializeSuperAdmin, initializeDemoData } from "@/utils/dataManager"

export default function SuperAdminLogin() {
  const [credentials, setCredentials] = useState({
    email: "",
    password: "",
  })
  const [error, setError] = useState("")
  const router = useRouter()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Initialize super admin and demo data
    initializeSuperAdmin()
    initializeDemoData()

    // Real super admin credentials (only for authorized access)
    if (credentials.email === "admin@mgbkpekanbaru.com" && credentials.password === "MGBKPekanbaru2024#Admin") {
      const superAdmin = {
        id: "super-admin",
        name: "Super Admin MGBK",
        email: "admin@mgbkpekanbaru.com",
        role: "admin",
        registrationDate: new Date().toISOString(),
        lastActive: new Date().toISOString(),
      }

      localStorage.setItem("user", JSON.stringify(superAdmin))
      router.push("/dashboard/admin")
    } else {
      setError("Email atau password salah. Akses terbatas untuk administrator resmi.")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-purple-50 to-blue-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="mb-6">
          <Link href="/" className="inline-flex items-center text-sm text-gray-600 hover:text-gray-900">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Kembali ke Beranda
          </Link>
        </div>

        <Card className="border-0 shadow-xl rounded-2xl">
          <CardHeader className="text-center pb-6">
            <div className="w-16 h-16 bg-gradient-to-r from-red-600 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <CardTitle className="text-2xl font-bold">Super Admin</CardTitle>
            <CardDescription>Akses khusus administrator sistem MGBK Pekanbaru</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="email">Email Administrator</Label>
                <Input
                  id="email"
                  type="email"
                  value={credentials.email}
                  onChange={(e) => setCredentials({ ...credentials, email: e.target.value })}
                  placeholder="Masukkan email administrator"
                  required
                />
              </div>
              <div>
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={credentials.password}
                  onChange={(e) => setCredentials({ ...credentials, password: e.target.value })}
                  placeholder="Masukkan password"
                  required
                />
              </div>

              {error && <div className="text-red-600 text-sm text-center p-3 bg-red-50 rounded-lg">{error}</div>}

              <Button type="submit" className="w-full rounded-xl bg-gradient-to-r from-red-600 to-purple-600">
                Masuk sebagai Super Admin
              </Button>
            </form>

            <div className="mt-6 p-4 bg-blue-50 rounded-xl">
              <p className="text-sm text-blue-800">
                <strong>Akses Terbatas:</strong> Halaman ini hanya untuk administrator resmi MGBK Pekanbaru. Hubungi tim
                teknis jika memerlukan akses.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
