"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ArrowLeft, LogIn } from "lucide-react"
import Link from "next/link"
import { getAllUsers, getAllTeachers, initializeDemoData } from "@/utils/dataManager"

export default function LoginPage() {
  const [credentials, setCredentials] = useState({
    email: "",
    password: "",
  })
  const [error, setError] = useState("")
  const router = useRouter()
  const searchParams = useSearchParams()
  const message = searchParams.get("message")

  useEffect(() => {
    // Initialize demo data on page load
    initializeDemoData()
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    // Demo credentials
    const demoCredentials = [
      { email: "siswa@demo.com", password: "demo123", role: "siswa", redirect: "/dashboard/siswa" },
      { email: "guru@demo.com", password: "demo123", role: "guru", redirect: "/dashboard/guru" },
    ]

    // Check demo credentials first
    const demoUser = demoCredentials.find(
      (cred) => cred.email === credentials.email && cred.password === credentials.password,
    )

    if (demoUser) {
      const userData = {
        id: `demo-${demoUser.role}`,
        name: demoUser.role === "siswa" ? "Demo Siswa" : "Demo Guru",
        email: demoUser.email,
        role: demoUser.role,
        school: "SMA Demo",
        registrationDate: new Date().toISOString(),
        lastActive: new Date().toISOString(),
      }

      localStorage.setItem("user", JSON.stringify(userData))
      router.push(demoUser.redirect)
      return
    }

    // Check real users
    const allUsers = getAllUsers()
    const allTeachers = getAllTeachers()

    const user = allUsers.find((u) => u.email === credentials.email)
    const teacher = allTeachers.find((t) => t.email === credentials.email)

    if (user && user.role === "siswa") {
      localStorage.setItem("user", JSON.stringify(user))
      router.push("/dashboard/siswa")
    } else if (teacher && teacher.status === "approved") {
      localStorage.setItem("user", JSON.stringify(teacher))
      router.push("/dashboard/guru")
    } else if (teacher && teacher.status === "pending") {
      setError("Akun Anda masih menunggu persetujuan admin")
    } else if (teacher && teacher.status === "rejected") {
      setError("Akun Anda ditolak oleh admin")
    } else {
      setError("Email atau password salah")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="mb-6">
          <Link href="/" className="inline-flex items-center text-sm text-gray-600 hover:text-gray-900">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Kembali ke Beranda
          </Link>
        </div>

        <Card className="border-0 shadow-xl rounded-2xl">
          <CardHeader className="text-center pb-6">
            <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <LogIn className="w-8 h-8 text-white" />
            </div>
            <CardTitle className="text-2xl font-bold">Masuk ke Akun</CardTitle>
            <CardDescription>Masukkan email dan password Anda</CardDescription>
          </CardHeader>
          <CardContent>
            {message && (
              <Alert className="mb-4">
                <AlertDescription>{message}</AlertDescription>
              </Alert>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={credentials.email}
                  onChange={(e) => setCredentials({ ...credentials, email: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={credentials.password}
                  onChange={(e) => setCredentials({ ...credentials, password: e.target.value })}
                  required
                />
              </div>

              {error && <div className="text-red-600 text-sm text-center">{error}</div>}

              <Button type="submit" className="w-full rounded-xl">
                Masuk
              </Button>
            </form>

            <div className="mt-6 text-center">
              <p className="text-sm text-gray-600">
                Belum punya akun?{" "}
                <Link href="/register" className="text-blue-600 hover:underline">
                  Daftar di sini
                </Link>
              </p>
            </div>

            <div className="mt-6 p-4 bg-blue-50 rounded-xl">
              <h4 className="font-semibold text-blue-900 mb-2">Akun Demo:</h4>
              <div className="text-sm text-blue-800 space-y-1">
                <p>Siswa: siswa@demo.com / demo123</p>
                <p>Guru: guru@demo.com / demo123</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
