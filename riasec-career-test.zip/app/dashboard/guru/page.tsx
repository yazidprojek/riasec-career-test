"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Users,
  Search,
  Download,
  BarChart3,
  LogOut,
  GraduationCap,
  FileText,
  TrendingUp,
  Trash2,
  Eye,
  MessageCircle,
  Clock,
  AlertTriangle,
  Calendar,
} from "lucide-react"
import {
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
} from "recharts"
import {
  getUsersBySchool,
  getTestResultsBySchool,
  deleteUser,
  exportToCSV,
  getTeacherSubscriptionStatus,
  getTeacherDaysRemaining,
  type User,
  type TestResult,
  type Teacher,
} from "@/utils/dataManager"
import jsPDF from "jspdf"
import * as XLSX from "xlsx"

const riasecColors = {
  R: "#ef4444",
  I: "#3b82f6",
  A: "#8b5cf6",
  S: "#10b981",
  E: "#f59e0b",
  C: "#6366f1",
}

export default function GuruDashboard() {
  const [user, setUser] = useState<Teacher | null>(null)
  const [students, setStudents] = useState<User[]>([])
  const [testResults, setTestResults] = useState<TestResult[]>([])
  const [filteredStudents, setFilteredStudents] = useState<User[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedStudent, setSelectedStudent] = useState<TestResult | null>(null)
  const [daysRemaining, setDaysRemaining] = useState(0)
  const [subscriptionStatus, setSubscriptionStatus] = useState<"active" | "warning" | "expired">("expired")
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      const parsed = JSON.parse(userData)
      if (parsed.role !== "guru") {
        router.push("/login")
        return
      }
      setUser(parsed)

      // Calculate subscription status
      const status = getTeacherSubscriptionStatus(parsed)
      const days = getTeacherDaysRemaining(parsed)
      setSubscriptionStatus(status)
      setDaysRemaining(days)

      loadSchoolData(parsed.school)
    } else {
      router.push("/login")
    }
  }, [router])

  const loadSchoolData = (school: string) => {
    if (!school) return

    const schoolStudents = getUsersBySchool(school)
    const schoolTestResults = getTestResultsBySchool(school)

    setStudents(schoolStudents)
    setTestResults(schoolTestResults)
    setFilteredStudents(schoolStudents)
  }

  useEffect(() => {
    if (searchTerm) {
      const filtered = students.filter(
        (student) =>
          student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          student.email.toLowerCase().includes(searchTerm.toLowerCase()),
      )
      setFilteredStudents(filtered)
    } else {
      setFilteredStudents(students)
    }
  }, [searchTerm, students])

  const handleLogout = () => {
    localStorage.removeUser("user")
    router.push("/")
  }

  const handleDeleteStudent = (studentId: string) => {
    if (confirm("Apakah Anda yakin ingin menghapus data siswa ini?")) {
      deleteUser(studentId)
      if (user?.school) {
        loadSchoolData(user.school)
      }
    }
  }

  const exportToExcel = () => {
    const exportData = testResults.map((result) => ({
      "Nama Siswa": result.userName,
      Sekolah: result.userSchool,
      "Tanggal Tes": new Date(result.date).toLocaleDateString("id-ID"),
      "Skor R (Realistic)": result.scores.R,
      "Skor I (Investigative)": result.scores.I,
      "Skor A (Artistic)": result.scores.A,
      "Skor S (Social)": result.scores.S,
      "Skor E (Enterprising)": result.scores.E,
      "Skor C (Conventional)": result.scores.C,
      "Tipe Dominan 1": result.dominantTypes[0] || "",
      "Tipe Dominan 2": result.dominantTypes[1] || "",
      "Tipe Dominan 3": result.dominantTypes[2] || "",
    }))

    const ws = XLSX.utils.json_to_sheet(exportData)
    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, ws, "Rekap Hasil Tes")
    XLSX.writeFile(
      wb,
      `rekap_hasil_tes_${user?.school?.replace(/\s+/g, "_")}_${new Date().toISOString().split("T")[0]}.xlsx`,
    )
  }

  const downloadStudentPDF = (result: TestResult) => {
    const pdf = new jsPDF({
      orientation: "portrait",
      unit: "mm",
      format: [210, 330], // F4 size
    })

    // Set margins (3,3,4,4)
    const leftMargin = 3
    const rightMargin = 3
    const topMargin = 4
    const bottomMargin = 4
    const pageWidth = 210
    const pageHeight = 330
    const contentWidth = pageWidth - leftMargin - rightMargin

    // Header
    pdf.setFontSize(20)
    pdf.text("Hasil Tes RIASEC", leftMargin, topMargin + 15)

    // Student info
    pdf.setFontSize(12)
    pdf.text(`Nama: ${result.userName}`, leftMargin, topMargin + 35)
    pdf.text(`Sekolah: ${result.userSchool}`, leftMargin, topMargin + 45)
    pdf.text(`Tanggal Tes: ${new Date(result.date).toLocaleDateString("id-ID")}`, leftMargin, topMargin + 55)

    // Scores
    pdf.text("Skor RIASEC:", leftMargin, topMargin + 75)
    let yPos = topMargin + 85
    Object.entries(result.scores).forEach(([type, score]) => {
      pdf.text(`${type}: ${score}`, leftMargin + 10, yPos)
      yPos += 10
    })

    // Dominant types
    pdf.text("Tipe Dominan:", leftMargin, yPos + 10)
    result.dominantTypes.forEach((type, index) => {
      pdf.text(`${index + 1}. ${type}`, leftMargin + 10, yPos + 20 + index * 10)
    })

    // Footer
    pdf.setFontSize(10)
    pdf.text("Copyright © mgbkpekanbaru", pageWidth / 2, pageHeight - bottomMargin, { align: "center" })

    pdf.save(`hasil_tes_${result.userName.replace(/\s+/g, "_")}.pdf`)
  }

  const generateComprehensiveReport = () => {
    const reportData = {
      summary: {
        totalStudents: students.length,
        completedTests: testResults.length,
        pendingTests: students.length - testResults.length,
        participationRate: students.length > 0 ? Math.round((testResults.length / students.length) * 100) : 0,
      },
      riasecDistribution: Object.keys(riasecColors).map((type) => ({
        type,
        count: testResults.filter((r) => r.dominantTypes[0] === type).length,
        percentage:
          testResults.length > 0
            ? Math.round((testResults.filter((r) => r.dominantTypes[0] === type).length / testResults.length) * 100)
            : 0,
      })),
      studentDetails: testResults.map((result) => ({
        nama: result.userName,
        tanggalTes: new Date(result.date).toLocaleDateString("id-ID"),
        tipeDominan: result.dominantTypes.slice(0, 3).join(", "),
        skorR: result.scores.R,
        skorI: result.scores.I,
        skorA: result.scores.A,
        skorS: result.scores.S,
        skorE: result.scores.E,
        skorC: result.scores.C,
      })),
    }

    const wb = XLSX.utils.book_new()

    // Summary sheet
    const summaryWs = XLSX.utils.json_to_sheet([reportData.summary])
    XLSX.utils.book_append_sheet(wb, summaryWs, "Ringkasan")

    // RIASEC Distribution sheet
    const riasecWs = XLSX.utils.json_to_sheet(reportData.riasecDistribution)
    XLSX.utils.book_append_sheet(wb, riasecWs, "Distribusi RIASEC")

    // Student Details sheet
    const detailsWs = XLSX.utils.json_to_sheet(reportData.studentDetails)
    XLSX.utils.book_append_sheet(wb, detailsWs, "Detail Siswa")

    XLSX.writeFile(
      wb,
      `laporan_lengkap_${user?.school?.replace(/\s+/g, "_")}_${new Date().toISOString().split("T")[0]}.xlsx`,
    )
  }

  if (!user) return <div>Loading...</div>

  // Analytics data
  const riasecDistribution = Object.keys(riasecColors).map((type) => ({
    type,
    count: testResults.filter((r) => r.dominantTypes[0] === type).length,
    color: riasecColors[type as keyof typeof riasecColors],
  }))

  const monthlyTrend = Array.from({ length: 6 }, (_, i) => {
    const date = new Date()
    date.setMonth(date.getMonth() - i)
    const month = date.toLocaleDateString("id-ID", { month: "short" })
    const count = testResults.filter((r) => {
      const resultDate = new Date(r.date)
      return resultDate.getMonth() === date.getMonth() && resultDate.getFullYear() === date.getFullYear()
    }).length
    return { month, tests: count }
  }).reverse()

  const studentsWithTests = students.filter((s) => testResults.some((r) => r.userId === s.id))
  const studentsWithoutTests = students.filter((s) => !testResults.some((r) => r.userId === s.id))

  const averageScores = Object.keys(riasecColors).map((type) => ({
    type,
    average:
      testResults.length > 0
        ? Math.round(
            testResults.reduce((sum, r) => sum + r.scores[type as keyof typeof r.scores], 0) / testResults.length,
          )
        : 0,
  }))

  const getSubscriptionBgColor = () => {
    if (subscriptionStatus === "active") return "bg-green-100 border-green-200"
    if (subscriptionStatus === "warning") return "bg-yellow-100 border-yellow-200"
    return "bg-red-100 border-red-200"
  }

  const getSubscriptionTextColor = () => {
    if (subscriptionStatus === "active") return "text-green-800"
    if (subscriptionStatus === "warning") return "text-yellow-800"
    return "text-red-800"
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-green-600 to-blue-600 rounded-xl flex items-center justify-center">
                <GraduationCap className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-semibold text-gray-900">Dashboard Guru</h1>
                <p className="text-sm text-gray-500">{user?.school}</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              {subscriptionStatus === "expired" && (
                <Button asChild className="bg-red-600 hover:bg-red-700">
                  <a href="https://wa.me/6285364613753" target="_blank" rel="noopener noreferrer">
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Perpanjang
                  </a>
                </Button>
              )}
              <Button variant="outline" onClick={handleLogout} className="flex items-center space-x-2 bg-transparent">
                <LogOut className="w-4 h-4" />
                <span>Keluar</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Subscription Status Card */}
        <Card className={`mb-6 border-2 ${getSubscriptionBgColor()}`}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center ${getSubscriptionBgColor()}`}>
                  {subscriptionStatus === "active" ? (
                    <Calendar className="w-6 h-6 text-green-600" />
                  ) : subscriptionStatus === "warning" ? (
                    <AlertTriangle className="w-6 h-6 text-yellow-600" />
                  ) : (
                    <Clock className="w-6 h-6 text-red-600" />
                  )}
                </div>
                <div>
                  <p className={`font-bold text-lg ${getSubscriptionTextColor()}`}>
                    {subscriptionStatus === "active" && "Akun Aktif"}
                    {subscriptionStatus === "warning" && "Segera Berakhir"}
                    {subscriptionStatus === "expired" && "Akun Berakhir"}
                  </p>
                  <p className={`text-sm ${getSubscriptionTextColor()}`}>
                    {subscriptionStatus === "expired"
                      ? "Hubungi WhatsApp untuk perpanjangan"
                      : `${daysRemaining} hari tersisa`}
                  </p>
                  {user.subscriptionEnd && (
                    <p className={`text-xs ${getSubscriptionTextColor()}`}>
                      Berakhir: {new Date(user.subscriptionEnd).toLocaleDateString("id-ID")}
                    </p>
                  )}
                </div>
              </div>
              {subscriptionStatus !== "expired" && (
                <div className={`text-right ${getSubscriptionTextColor()}`}>
                  <p className="text-2xl font-bold">{daysRemaining}</p>
                  <p className="text-sm">Hari Tersisa</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="border-0 shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                  <Users className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{students.length}</p>
                  <p className="text-sm text-gray-600">Total Siswa</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                  <BarChart3 className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{testResults.length}</p>
                  <p className="text-sm text-gray-600">Tes Selesai</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                  <FileText className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{studentsWithoutTests.length}</p>
                  <p className="text-sm text-gray-600">Belum Tes</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-orange-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">
                    {students.length > 0 ? Math.round((testResults.length / students.length) * 100) : 0}%
                  </p>
                  <p className="text-sm text-gray-600">Tingkat Partisipasi</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Student List */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>Data Siswa</CardTitle>
                    <CardDescription>Siswa dari {user?.school}</CardDescription>
                  </div>
                  <div className="flex space-x-2">
                    <Button onClick={exportToExcel} className="flex items-center space-x-2">
                      <Download className="w-4 h-4" />
                      <span>Export Excel</span>
                    </Button>
                    <Button
                      onClick={generateComprehensiveReport}
                      variant="outline"
                      className="flex items-center space-x-2 bg-transparent"
                    >
                      <FileText className="w-4 h-4" />
                      <span>Laporan Lengkap</span>
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {/* Search */}
                <div className="mb-6">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      placeholder="Cari nama siswa..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>

                {/* Student Table */}
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-3 px-4">Nama</th>
                        <th className="text-left py-3 px-4">Email</th>
                        <th className="text-left py-3 px-4">Status Tes</th>
                        <th className="text-left py-3 px-4">Tipe Dominan</th>
                        <th className="text-center py-3 px-4">Aksi</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredStudents.map((student) => {
                        const studentTest = testResults.find((r) => r.userId === student.id)
                        return (
                          <tr key={student.id} className="border-b hover:bg-gray-50">
                            <td className="py-4 px-4">
                              <div>
                                <p className="font-medium text-gray-900">{student.name}</p>
                                <p className="text-sm text-gray-500">
                                  Daftar: {new Date(student.registrationDate).toLocaleDateString("id-ID")}
                                </p>
                              </div>
                            </td>
                            <td className="py-4 px-4 text-sm text-gray-600">{student.email}</td>
                            <td className="py-4 px-4">
                              <Badge variant={studentTest ? "default" : "secondary"}>
                                {studentTest ? "Selesai" : "Belum Tes"}
                              </Badge>
                            </td>
                            <td className="py-4 px-4">
                              {studentTest ? (
                                <div className="flex space-x-1">
                                  {studentTest.dominantTypes.slice(0, 3).map((type, index) => (
                                    <Badge
                                      key={type}
                                      variant="secondary"
                                      className="text-xs px-2 py-1"
                                      style={{
                                        backgroundColor: `${riasecColors[type as keyof typeof riasecColors]}20`,
                                        color: riasecColors[type as keyof typeof riasecColors],
                                      }}
                                    >
                                      #{index + 1} {type}
                                    </Badge>
                                  ))}
                                </div>
                              ) : (
                                <span className="text-gray-400">-</span>
                              )}
                            </td>
                            <td className="py-4 px-4">
                              <div className="flex space-x-2 justify-center">
                                {studentTest && (
                                  <>
                                    <Dialog>
                                      <DialogTrigger asChild>
                                        <Button
                                          variant="outline"
                                          size="sm"
                                          onClick={() => setSelectedStudent(studentTest)}
                                          title="Lihat Detail"
                                        >
                                          <Eye className="w-4 h-4" />
                                        </Button>
                                      </DialogTrigger>
                                      <DialogContent className="max-w-2xl">
                                        <DialogHeader>
                                          <DialogTitle>Detail Hasil Tes</DialogTitle>
                                          <DialogDescription>
                                            Hasil tes RIASEC untuk {studentTest?.userName}
                                          </DialogDescription>
                                        </DialogHeader>
                                        {selectedStudent && (
                                          <div className="space-y-4">
                                            <div className="grid grid-cols-2 gap-4">
                                              <div>
                                                <h4 className="font-semibold mb-2">Informasi Siswa</h4>
                                                <p>
                                                  <strong>Nama:</strong> {selectedStudent.userName}
                                                </p>
                                                <p>
                                                  <strong>Sekolah:</strong> {selectedStudent.userSchool}
                                                </p>
                                                <p>
                                                  <strong>Tanggal Tes:</strong>{" "}
                                                  {new Date(selectedStudent.date).toLocaleDateString("id-ID")}
                                                </p>
                                              </div>
                                              <div>
                                                <h4 className="font-semibold mb-2">Skor RIASEC</h4>
                                                {Object.entries(selectedStudent.scores).map(([type, score]) => (
                                                  <div key={type} className="flex justify-between">
                                                    <span>{type}:</span>
                                                    <span className="font-medium">{score}</span>
                                                  </div>
                                                ))}
                                              </div>
                                            </div>
                                            <div>
                                              <h4 className="font-semibold mb-2">Tipe Dominan</h4>
                                              <div className="flex space-x-2">
                                                {selectedStudent.dominantTypes.map((type, index) => (
                                                  <Badge key={type} variant="secondary">
                                                    #{index + 1} {type}
                                                  </Badge>
                                                ))}
                                              </div>
                                            </div>
                                            <Button
                                              onClick={() => downloadStudentPDF(selectedStudent)}
                                              className="w-full"
                                            >
                                              <Download className="w-4 h-4 mr-2" />
                                              Download PDF
                                            </Button>
                                          </div>
                                        )}
                                      </DialogContent>
                                    </Dialog>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => downloadStudentPDF(studentTest)}
                                      title="Download PDF"
                                    >
                                      <Download className="w-4 h-4" />
                                    </Button>
                                  </>
                                )}
                                <Button
                                  variant="destructive"
                                  size="sm"
                                  onClick={() => handleDeleteStudent(student.id)}
                                  title="Hapus Siswa"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>

                {filteredStudents.length === 0 && (
                  <div className="text-center py-8">
                    <p className="text-gray-500">Tidak ada data siswa yang ditemukan</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Students Without Tests */}
            {studentsWithoutTests.length > 0 && (
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <AlertTriangle className="w-5 h-5 text-orange-500" />
                    <span>Siswa Belum Tes ({studentsWithoutTests.length})</span>
                  </CardTitle>
                  <CardDescription>Daftar siswa yang sudah memiliki akun tapi belum melaksanakan tes</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {studentsWithoutTests.map((student) => (
                      <div
                        key={student.id}
                        className="flex justify-between items-center p-3 bg-orange-50 rounded-lg border border-orange-200"
                      >
                        <div>
                          <p className="font-medium text-gray-900">{student.name}</p>
                          <p className="text-sm text-gray-600">{student.email}</p>
                          <p className="text-xs text-gray-500">
                            Daftar: {new Date(student.registrationDate).toLocaleDateString("id-ID")}
                          </p>
                        </div>
                        <Badge variant="secondary" className="bg-orange-100 text-orange-800">
                          Belum Tes
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Analytics Sidebar */}
          <div className="space-y-6">
            {/* RIASEC Distribution */}
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="text-lg">Distribusi Tipe RIASEC</CardTitle>
                <CardDescription>Siswa per tipe dominan</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={riasecDistribution}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ type, count }) => (count > 0 ? `${type}: ${count}` : "")}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="count"
                      >
                        {riasecDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Average Scores */}
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="text-lg">Rata-rata Skor</CardTitle>
                <CardDescription>Skor rata-rata per tipe RIASEC</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={averageScores}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="type" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="average" fill="#8884d8" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Monthly Trend */}
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="text-lg">Tren Bulanan</CardTitle>
                <CardDescription>Jumlah tes per bulan</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={monthlyTrend}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Line type="monotone" dataKey="tests" stroke="#8884d8" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="text-lg">Aksi Cepat</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <Button variant="outline" className="w-full justify-start bg-transparent" onClick={exportToExcel}>
                    <Download className="w-4 h-4 mr-2" />
                    Export Rekap Excel
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start bg-transparent"
                    onClick={() => {
                      const summaryData = [
                        {
                          "Total Siswa": students.length,
                          "Tes Selesai": testResults.length,
                          "Belum Tes": studentsWithoutTests.length,
                          "Tingkat Partisipasi": `${students.length > 0 ? Math.round((testResults.length / students.length) * 100) : 0}%`,
                          Sekolah: user?.school,
                          "Tanggal Laporan": new Date().toLocaleDateString("id-ID"),
                        },
                      ]
                      exportToCSV(
                        summaryData,
                        `ringkasan_${user?.school?.replace(/\s+/g, "_")}_${new Date().toISOString().split("T")[0]}.csv`,
                      )
                    }}
                  >
                    <BarChart3 className="w-4 h-4 mr-2" />
                    Laporan Ringkasan
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start bg-transparent"
                    onClick={() => {
                      const detailData = studentsWithoutTests.map((student) => ({
                        Nama: student.name,
                        Email: student.email,
                        "Tanggal Daftar": new Date(student.registrationDate).toLocaleDateString("id-ID"),
                        Status: "Belum Tes",
                      }))
                      exportToCSV(
                        detailData,
                        `siswa_belum_tes_${user?.school?.replace(/\s+/g, "_")}_${new Date().toISOString().split("T")[0]}.csv`,
                      )
                    }}
                  >
                    <Users className="w-4 h-4 mr-2" />
                    Daftar Belum Tes
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
