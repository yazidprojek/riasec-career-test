"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Download, Trophy, Target, Briefcase } from "lucide-react"
import {
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
} from "recharts"
import jsPDF from "jspdf"
import html2canvas from "html2canvas"

const riasecData = {
  R: { name: "Realistic", color: "#ef4444", description: "Praktis, hands-on, suka bekerja dengan alat dan mesin" },
  I: { name: "Investigative", color: "#3b82f6", description: "Analitis, suka memecahkan masalah dan penelitian" },
  A: { name: "Artistic", color: "#8b5cf6", description: "Kreatif, ekspresif, suka seni dan desain" },
  S: { name: "Social", color: "#10b981", description: "Peduli, suka membantu dan berinteraksi dengan orang" },
  E: { name: "Enterprising", color: "#f59e0b", description: "Ambisius, suka memimpin dan berbisnis" },
  C: { name: "Conventional", color: "#6366f1", description: "Terorganisir, detail, suka struktur dan aturan" },
}

const careerSuggestions = {
  R: ["Teknisi Komputer", "Montir", "Pilot", "Ahli Listrik", "Arsitek", "Chef", "Fotografer"],
  I: ["Ilmuwan", "Peneliti", "Dokter", "Psikolog", "Analis Data", "Farmasis", "Software Engineer"],
  A: ["Seniman", "Desainer Grafis", "Musisi", "Penulis", "Aktor", "Fashion Designer", "Animator"],
  S: ["Guru", "Perawat", "Konselor", "Social Worker", "Terapis", "HR Specialist", "Event Organizer"],
  E: ["Pengusaha", "Sales Manager", "Marketing Director", "Business Consultant", "CEO", "Lawyer"],
  C: ["Akuntan", "Admin Kantor", "Bank Teller", "Auditor", "Secretary", "Quality Control", "Bookkeeper"],
}

export default function ResultsPage() {
  const [testResult, setTestResult] = useState<any>(null)
  const [user, setUser] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    const history = localStorage.getItem("testHistory")

    if (userData && history) {
      setUser(JSON.parse(userData))
      const testHistory = JSON.parse(history)
      if (testHistory.length > 0) {
        setTestResult(testHistory[0])
      }
    } else {
      router.push("/dashboard/siswa")
    }
  }, [router])

  const generatePDF = async () => {
    const element = document.getElementById("results-content")
    if (!element) return

    const canvas = await html2canvas(element, {
      scale: 2,
      useCORS: true,
      allowTaint: true,
    })

    const imgData = canvas.toDataURL("image/png")
    const pdf = new jsPDF("p", "mm", "a4")

    const imgWidth = 210
    const pageHeight = 295
    const imgHeight = (canvas.height * imgWidth) / canvas.width
    let heightLeft = imgHeight

    let position = 0

    pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight)
    heightLeft -= pageHeight

    while (heightLeft >= 0) {
      position = heightLeft - imgHeight
      pdf.addPage()
      pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight)
      heightLeft -= pageHeight
    }

    // Add footer
    const pageCount = pdf.getNumberOfPages()
    for (let i = 1; i <= pageCount; i++) {
      pdf.setPage(i)
      pdf.setFontSize(10)
      pdf.setTextColor(128, 128, 128)
      pdf.text("Copyright © mgbkpekanbaru", 105, 285, { align: "center" })
    }

    pdf.save(`RIASEC_Result_${user?.name || "User"}.pdf`)
  }

  if (!testResult || !user) {
    return <div>Loading...</div>
  }

  const scores = testResult.scores
  const sortedScores = Object.entries(scores)
    .sort(([, a], [, b]) => (b as number) - (a as number))
    .slice(0, 3)

  const radarData = Object.entries(scores).map(([type, score]) => ({
    type: riasecData[type as keyof typeof riasecData].name,
    score: score as number,
    fullMark: 30,
  }))

  const pieData = Object.entries(scores).map(([type, score]) => ({
    name: riasecData[type as keyof typeof riasecData].name,
    value: score as number,
    color: riasecData[type as keyof typeof riasecData].color,
  }))

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <Button variant="ghost" onClick={() => router.back()}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Kembali
              </Button>
              <div>
                <h1 className="text-lg font-semibold text-gray-900">Hasil Tes RIASEC</h1>
                <p className="text-sm text-gray-500">Analisis Minat Karier</p>
              </div>
            </div>
            <Button onClick={generatePDF} className="flex items-center space-x-2">
              <Download className="w-4 h-4" />
              <span>Download PDF</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div id="results-content" className="space-y-8">
          {/* Header Info */}
          <Card className="border-0 shadow-lg">
            <CardHeader className="text-center">
              <div className="w-20 h-20 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Trophy className="w-10 h-10 text-white" />
              </div>
              <CardTitle className="text-3xl">Selamat! Tes Selesai</CardTitle>
              <CardDescription className="text-lg">
                Berikut adalah hasil analisis minat karier RIASEC Anda
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-6 text-center">
                <div>
                  <p className="text-2xl font-bold text-gray-900">{user.fullName || user.name}</p>
                  <p className="text-sm text-gray-600">Nama Lengkap</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{user.school || "Tidak diisi"}</p>
                  <p className="text-sm text-gray-600">Sekolah</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">
                    {new Date(testResult.date).toLocaleDateString("id-ID")}
                  </p>
                  <p className="text-sm text-gray-600">Tanggal Tes</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Top 3 Dominant Types */}
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Target className="w-6 h-6 text-yellow-500" />
                <span>3 Tipe Dominan Anda</span>
              </CardTitle>
              <CardDescription>
                Berdasarkan hasil tes, berikut adalah tipe kepribadian karier yang paling dominan
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-6">
                {sortedScores.map(([type, score], index) => (
                  <div
                    key={type}
                    className="text-center p-6 bg-gradient-to-br from-gray-50 to-white rounded-2xl border"
                  >
                    <div className="relative mb-4">
                      <div
                        className="w-20 h-20 rounded-full flex items-center justify-center mx-auto text-white text-2xl font-bold"
                        style={{ backgroundColor: riasecData[type as keyof typeof riasecData].color }}
                      >
                        {type}
                      </div>
                      <div className="absolute -top-2 -right-2 w-8 h-8 bg-yellow-400 rounded-full flex items-center justify-center text-white font-bold text-sm">
                        #{index + 1}
                      </div>
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">
                      {riasecData[type as keyof typeof riasecData].name}
                    </h3>
                    <p className="text-sm text-gray-600 mb-3">
                      {riasecData[type as keyof typeof riasecData].description}
                    </p>
                    <Badge variant="secondary" className="text-lg px-3 py-1">
                      Skor: {score as number}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Charts */}
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Radar Chart */}
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Radar Chart - Profil RIASEC</CardTitle>
                <CardDescription>Visualisasi skor untuk semua 6 tipe kepribadian</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <RadarChart data={radarData}>
                      <PolarGrid />
                      <PolarAngleAxis dataKey="type" />
                      <PolarRadiusAxis angle={90} domain={[0, 30]} />
                      <Radar
                        name="Skor"
                        dataKey="score"
                        stroke="#8884d8"
                        fill="#8884d8"
                        fillOpacity={0.3}
                        strokeWidth={2}
                      />
                    </RadarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Pie Chart */}
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Pie Chart - Distribusi Minat</CardTitle>
                <CardDescription>Proporsi minat untuk setiap tipe kepribadian</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={pieData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {pieData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Detailed Scores Table */}
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle>Tabel Skor Detail</CardTitle>
              <CardDescription>Breakdown skor untuk setiap tipe dengan deskripsi dan saran karier</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4">Tipe</th>
                      <th className="text-left py-3 px-4">Nama</th>
                      <th className="text-center py-3 px-4">Skor</th>
                      <th className="text-left py-3 px-4">Deskripsi</th>
                      <th className="text-left py-3 px-4">Saran Karier</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Object.entries(scores)
                      .sort(([, a], [, b]) => (b as number) - (a as number))
                      .map(([type, score]) => (
                        <tr key={type} className="border-b hover:bg-gray-50">
                          <td className="py-4 px-4">
                            <div
                              className="w-10 h-10 rounded-lg flex items-center justify-center text-white font-bold"
                              style={{ backgroundColor: riasecData[type as keyof typeof riasecData].color }}
                            >
                              {type}
                            </div>
                          </td>
                          <td className="py-4 px-4 font-medium">{riasecData[type as keyof typeof riasecData].name}</td>
                          <td className="py-4 px-4 text-center">
                            <Badge variant="secondary" className="text-lg px-3 py-1">
                              {score as number}
                            </Badge>
                          </td>
                          <td className="py-4 px-4 text-sm text-gray-600">
                            {riasecData[type as keyof typeof riasecData].description}
                          </td>
                          <td className="py-4 px-4">
                            <div className="flex flex-wrap gap-1">
                              {careerSuggestions[type as keyof typeof careerSuggestions].slice(0, 3).map((career) => (
                                <Badge key={career} variant="outline" className="text-xs">
                                  {career}
                                </Badge>
                              ))}
                            </div>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          {/* Career Suggestions */}
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Briefcase className="w-6 h-6 text-blue-500" />
                <span>Saran Karier Berdasarkan Tipe Dominan</span>
              </CardTitle>
              <CardDescription>Rekomendasi karier yang sesuai dengan 3 tipe dominan Anda</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-6">
                {sortedScores.map(([type, score], index) => (
                  <div key={type} className="p-6 bg-gradient-to-br from-gray-50 to-white rounded-2xl border">
                    <div className="flex items-center space-x-3 mb-4">
                      <div
                        className="w-12 h-12 rounded-xl flex items-center justify-center text-white font-bold"
                        style={{ backgroundColor: riasecData[type as keyof typeof riasecData].color }}
                      >
                        {type}
                      </div>
                      <div>
                        <h3 className="font-bold text-gray-900">{riasecData[type as keyof typeof riasecData].name}</h3>
                        <p className="text-sm text-gray-600">Ranking #{index + 1}</p>
                      </div>
                    </div>
                    <div className="space-y-2">
                      {careerSuggestions[type as keyof typeof careerSuggestions].map((career) => (
                        <div key={career} className="flex items-center space-x-2">
                          <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                          <span className="text-sm text-gray-700">{career}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Interpretation */}
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle>Interpretasi Hasil</CardTitle>
              <CardDescription>Penjelasan tentang hasil tes RIASEC Anda</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="prose max-w-none">
                <p className="text-gray-700 leading-relaxed mb-4">
                  Berdasarkan hasil tes RIASEC Anda, tipe kepribadian karier yang paling dominan adalah{" "}
                  <strong>{riasecData[sortedScores[0][0] as keyof typeof riasecData].name}</strong> dengan skor{" "}
                  <strong>{sortedScores[0][1]}</strong>. Ini menunjukkan bahwa Anda memiliki minat yang kuat pada{" "}
                  {riasecData[sortedScores[0][0] as keyof typeof riasecData].description.toLowerCase()}.
                </p>

                <p className="text-gray-700 leading-relaxed mb-4">
                  Tipe kedua dan ketiga yang dominan adalah{" "}
                  <strong>{riasecData[sortedScores[1][0] as keyof typeof riasecData].name}</strong> dan{" "}
                  <strong>{riasecData[sortedScores[2][0] as keyof typeof riasecData].name}</strong>. Kombinasi ketiga
                  tipe ini memberikan gambaran yang komprehensif tentang minat karier Anda.
                </p>

                <div className="bg-blue-50 p-4 rounded-xl">
                  <h4 className="font-semibold text-blue-900 mb-2">Saran untuk Pengembangan Karier:</h4>
                  <ul className="text-blue-800 space-y-1">
                    <li>• Eksplorasi karier yang sesuai dengan tipe dominan Anda</li>
                    <li>• Kembangkan keterampilan yang mendukung minat utama</li>
                    <li>• Pertimbangkan pendidikan atau pelatihan yang relevan</li>
                    <li>• Cari pengalaman praktis melalui magang atau volunteer</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
