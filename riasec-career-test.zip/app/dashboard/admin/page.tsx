"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Shield,
  Users,
  GraduationCap,
  Settings,
  FileText,
  Download,
  Upload,
  Edit,
  Trash2,
  Check,
  X,
  LogOut,
  Plus,
  BarChart3,
  Search,
  UserPlus,
  Key,
  MessageSquare,
  Briefcase,
  Star,
  Filter,
} from "lucide-react"
import {
  getAllUsers,
  getAllTeachers,
  getAllTestResults,
  getAllTestimonials,
  getAllCareerSuggestions,
  updateTeacherStatus,
  deleteUser,
  deleteTeacher,
  deleteTestimonial,
  deleteCareerSuggestion,
  saveUser,
  saveTestimonial,
  saveCareerSuggestion,
  exportToCSV,
  generateQuestionTemplate,
  getTeacherSubscriptionStatus,
  type User,
  type Teacher,
  type TestResult,
  type Testimonial,
  type CareerSuggestion,
} from "@/utils/dataManager"
import { getAllQuestions } from "@/data/questions"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts"
import jsPDF from "jspdf"
import * as XLSX from "xlsx"

export default function AdminDashboard() {
  const [user, setUser] = useState<any>(null)
  const [teachers, setTeachers] = useState<Teacher[]>([])
  const [users, setUsers] = useState<User[]>([])
  const [testResults, setTestResults] = useState<TestResult[]>([])
  const [testimonials, setTestimonials] = useState<Testimonial[]>([])
  const [careerSuggestions, setCareerSuggestions] = useState<CareerSuggestion[]>([])
  const [questions, setQuestions] = useState(getAllQuestions())
  const [activeTab, setActiveTab] = useState("overview")
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedSchool, setSelectedSchool] = useState("all")
  const [teacherStatusFilter, setTeacherStatusFilter] = useState("all")
  const [showAddAdmin, setShowAddAdmin] = useState(false)
  const [showChangePassword, setShowChangePassword] = useState(false)
  const [showAddTestimonial, setShowAddTestimonial] = useState(false)
  const [showEditTestimonial, setShowEditTestimonial] = useState(false)
  const [showAddCareer, setShowAddCareer] = useState(false)
  const [showAddQuestion, setShowAddQuestion] = useState(false)
  const [newAdmin, setNewAdmin] = useState({ name: "", email: "", password: "" })
  const [passwordChange, setPasswordChange] = useState({ current: "", new: "", confirm: "" })
  const [newTestimonial, setNewTestimonial] = useState({
    name: "",
    role: "",
    school: "",
    content: "",
    rating: 5,
  })
  const [editingTestimonial, setEditingTestimonial] = useState<Testimonial | null>(null)
  const [newCareer, setNewCareer] = useState({
    type: "R" as "R" | "I" | "A" | "S" | "E" | "C",
    career: "",
    description: "",
    matchPercentage: 85,
  })
  const [newQuestion, setNewQuestion] = useState({
    bagian: 1,
    type: "R" as "R" | "I" | "A" | "S" | "E" | "C",
    text: "",
  })
  const [editingQuestion, setEditingQuestion] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      const parsed = JSON.parse(userData)
      if (parsed.role !== "admin") {
        router.push("/login")
        return
      }
      setUser(parsed)
      loadData()
    } else {
      router.push("/login")
    }
  }, [router])

  const loadData = () => {
    setTeachers(getAllTeachers())
    setUsers(getAllUsers().filter((u) => u.role === "siswa"))
    setTestResults(getAllTestResults())
    setTestimonials(getAllTestimonials())
    setCareerSuggestions(getAllCareerSuggestions())
  }

  const handleLogout = () => {
    localStorage.removeItem("user")
    router.push("/")
  }

  const approveTeacher = (id: string) => {
    updateTeacherStatus(id, "approved")
    loadData()
  }

  const rejectTeacher = (id: string) => {
    updateTeacherStatus(id, "rejected")
    loadData()
  }

  const handleDeleteUser = (id: string) => {
    if (confirm("Apakah Anda yakin ingin menghapus pengguna ini?")) {
      deleteUser(id)
      loadData()
    }
  }

  const handleDeleteTeacher = (id: string) => {
    if (confirm("Apakah Anda yakin ingin menghapus guru ini?")) {
      deleteTeacher(id)
      loadData()
    }
  }

  const handleAddAdmin = () => {
    if (newAdmin.name && newAdmin.email && newAdmin.password) {
      const adminUser: User = {
        id: Date.now().toString(),
        name: newAdmin.name,
        email: newAdmin.email,
        role: "admin",
        registrationDate: new Date().toISOString(),
        lastActive: new Date().toISOString(),
      }
      saveUser(adminUser)
      setNewAdmin({ name: "", email: "", password: "" })
      setShowAddAdmin(false)
      loadData()
      alert("Admin baru berhasil ditambahkan!")
    }
  }

  const handleChangePassword = () => {
    if (passwordChange.new === passwordChange.confirm) {
      alert("Password berhasil diubah!")
      setPasswordChange({ current: "", new: "", confirm: "" })
      setShowChangePassword(false)
    } else {
      alert("Password baru tidak cocok!")
    }
  }

  const handleAddTestimonial = () => {
    if (newTestimonial.name && newTestimonial.content) {
      const testimonial: Testimonial = {
        id: Date.now().toString(),
        ...newTestimonial,
        isActive: true,
        createdAt: new Date().toISOString(),
      }
      saveTestimonial(testimonial)
      setNewTestimonial({ name: "", role: "", school: "", content: "", rating: 5 })
      setShowAddTestimonial(false)
      loadData()
      alert("Testimoni berhasil ditambahkan!")
    }
  }

  const handleEditTestimonial = () => {
    if (editingTestimonial) {
      saveTestimonial(editingTestimonial)
      setEditingTestimonial(null)
      setShowEditTestimonial(false)
      loadData()
      alert("Testimoni berhasil diperbarui!")
    }
  }

  const handleAddCareer = () => {
    if (newCareer.career && newCareer.description) {
      const career: CareerSuggestion = {
        id: Date.now().toString(),
        ...newCareer,
        isActive: true,
      }
      saveCareerSuggestion(career)
      setNewCareer({ type: "R", career: "", description: "", matchPercentage: 85 })
      setShowAddCareer(false)
      loadData()
      alert("Saran karier berhasil ditambahkan!")
    }
  }

  const handleAddQuestion = () => {
    if (newQuestion.text) {
      const question = {
        id: Date.now(),
        ...newQuestion,
        isActive: true,
      }
      const updatedQuestions = [...questions, question]
      setQuestions(updatedQuestions)
      localStorage.setItem("customQuestions", JSON.stringify(updatedQuestions))
      setNewQuestion({ bagian: 1, type: "R", text: "" })
      setShowAddQuestion(false)
      alert("Pertanyaan berhasil ditambahkan!")
    }
  }

  const handleEditQuestion = (question: any) => {
    const updatedQuestions = questions.map((q) => (q.id === question.id ? { ...question } : q))
    setQuestions(updatedQuestions)
    localStorage.setItem("customQuestions", JSON.stringify(updatedQuestions))
    setEditingQuestion(null)
    alert("Pertanyaan berhasil diperbarui!")
  }

  const handleUploadCSV = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        const csv = e.target?.result as string
        const lines = csv.split("\n")
        const headers = lines[0].split(",")

        const newQuestions = lines
          .slice(1)
          .map((line, index) => {
            const values = line.split(",")
            return {
              id: Date.now() + index,
              bagian: Number.parseInt(values[0]) || 1,
              type: values[1] || "R",
              text: values[2] || "",
              isActive: values[3] === "true" || true,
            }
          })
          .filter((q) => q.text)

        const updatedQuestions = [...questions, ...newQuestions]
        setQuestions(updatedQuestions)
        localStorage.setItem("customQuestions", JSON.stringify(updatedQuestions))
        alert(`${newQuestions.length} pertanyaan berhasil ditambahkan!`)
      }
      reader.readAsText(file)
    }
  }

  const exportAnalyticsReport = (type: "excel" | "pdf") => {
    const reportData = {
      summary: {
        totalUsers: users.length,
        totalTeachers: teachers.filter((t) => t.status === "approved").length,
        totalTests: testResults.length,
        pendingTeachers: teachers.filter((t) => t.status === "pending").length,
      },
      riasecDistribution: ["R", "I", "A", "S", "E", "C"].map((type) => ({
        type,
        count: testResults.filter((r) => r.dominantTypes[0] === type).length,
      })),
      monthlyTrend: Array.from({ length: 6 }, (_, i) => {
        const date = new Date()
        date.setMonth(date.getMonth() - i)
        const month = date.toLocaleDateString("id-ID", { year: "numeric", month: "long" })
        const count = testResults.filter((r) => {
          const resultDate = new Date(r.date)
          return resultDate.getMonth() === date.getMonth() && resultDate.getFullYear() === date.getFullYear()
        }).length
        return { month, tests: count }
      }).reverse(),
    }

    if (type === "excel") {
      const wb = XLSX.utils.book_new()

      // Summary sheet
      const summaryWs = XLSX.utils.json_to_sheet([reportData.summary])
      XLSX.utils.book_append_sheet(wb, summaryWs, "Ringkasan")

      // RIASEC Distribution sheet
      const riasecWs = XLSX.utils.json_to_sheet(reportData.riasecDistribution)
      XLSX.utils.book_append_sheet(wb, riasecWs, "Distribusi RIASEC")

      // Monthly Trend sheet
      const trendWs = XLSX.utils.json_to_sheet(reportData.monthlyTrend)
      XLSX.utils.book_append_sheet(wb, trendWs, "Tren Bulanan")

      XLSX.writeFile(wb, `laporan_analytics_${new Date().toISOString().split("T")[0]}.xlsx`)
    } else {
      // PDF with charts
      const pdf = new jsPDF()

      // Title
      pdf.setFontSize(20)
      pdf.text("Laporan Analytics RIASEC", 20, 30)

      // Summary
      pdf.setFontSize(14)
      pdf.text("Ringkasan:", 20, 50)
      pdf.setFontSize(12)
      pdf.text(`Total Siswa: ${reportData.summary.totalUsers}`, 30, 65)
      pdf.text(`Total Guru: ${reportData.summary.totalTeachers}`, 30, 75)
      pdf.text(`Total Tes: ${reportData.summary.totalTests}`, 30, 85)
      pdf.text(`Guru Pending: ${reportData.summary.pendingTeachers}`, 30, 95)

      // RIASEC Distribution
      pdf.text("Distribusi RIASEC:", 20, 115)
      let yPos = 125
      reportData.riasecDistribution.forEach((item) => {
        pdf.text(`${item.type}: ${item.count} siswa`, 30, yPos)
        yPos += 10
      })

      // Footer
      pdf.setFontSize(10)
      pdf.text("Copyright © mgbkpekanbaru", 105, 280, { align: "center" })

      pdf.save(`laporan_analytics_${new Date().toISOString().split("T")[0]}.pdf`)
    }
  }

  if (!user) return <div>Loading...</div>

  const filteredUsers = searchTerm
    ? users.filter(
        (u) =>
          u.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          u.school?.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    : users

  const schoolFilteredUsers =
    selectedSchool === "all" ? filteredUsers : filteredUsers.filter((u) => u.school === selectedSchool)

  // Filter teachers by status
  const filteredTeachers =
    teacherStatusFilter === "all"
      ? teachers
      : teachers.filter((t) => {
          if (teacherStatusFilter === "pending") return t.status === "pending"
          if (teacherStatusFilter === "approved") return t.status === "approved"
          if (teacherStatusFilter === "rejected") return t.status === "rejected"
          if (teacherStatusFilter === "warning") {
            const status = getTeacherSubscriptionStatus(t)
            return status === "warning"
          }
          if (teacherStatusFilter === "expired") {
            const status = getTeacherSubscriptionStatus(t)
            return status === "expired"
          }
          return true
        })

  const schools = [...new Set(users.map((u) => u.school).filter(Boolean))]
  const pendingTeachers = teachers.filter((t) => t.status === "pending").length
  const totalUsers = users.length
  const totalTeachers = teachers.filter((t) => t.status === "approved").length
  const activeQuestions = questions.filter((q) => q.isActive).length

  // Analytics data
  const riasecDistribution = ["R", "I", "A", "S", "E", "C"].map((type) => ({
    type,
    count: testResults.filter((r) => r.dominantTypes[0] === type).length,
  }))

  const monthlyTrend = Array.from({ length: 6 }, (_, i) => {
    const date = new Date()
    date.setMonth(date.getMonth() - i)
    const month = date.toLocaleDateString("id-ID", { month: "short" })
    const count = testResults.filter((r) => {
      const resultDate = new Date(r.date)
      return resultDate.getMonth() === date.getMonth() && resultDate.getFullYear() === date.getFullYear()
    }).length
    return { month, tests: count }
  }).reverse()

  const getStatusBadgeColor = (teacher: Teacher) => {
    if (teacher.status === "pending") return "bg-red-100 text-red-800 border-red-200"
    if (teacher.status === "rejected") return "bg-red-100 text-red-800 border-red-200"

    const subscriptionStatus = getTeacherSubscriptionStatus(teacher)
    if (subscriptionStatus === "expired") return "bg-red-100 text-red-800 border-red-200"
    if (subscriptionStatus === "warning") return "bg-yellow-100 text-yellow-800 border-yellow-200"
    return "bg-green-100 text-green-800 border-green-200"
  }

  const getStatusText = (teacher: Teacher) => {
    if (teacher.status === "pending") return "Pending"
    if (teacher.status === "rejected") return "Ditolak"
    if (teacher.status === "approved") {
      const subscriptionStatus = getTeacherSubscriptionStatus(teacher)
      if (subscriptionStatus === "expired") return "Berakhir"
      if (subscriptionStatus === "warning") return "Segera Berakhir"
      return "Aktif"
    }
    return teacher.status
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-red-600 to-purple-600 rounded-xl flex items-center justify-center">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-semibold text-gray-900">Dashboard Admin</h1>
                <p className="text-sm text-gray-500">Kelola platform RIASEC</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Dialog open={showAddAdmin} onOpenChange={setShowAddAdmin}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="flex items-center space-x-2 bg-transparent">
                    <UserPlus className="w-4 h-4" />
                    <span>Tambah Admin</span>
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Tambah Admin Baru</DialogTitle>
                    <DialogDescription>Buat akun administrator baru</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="admin-name">Nama Lengkap</Label>
                      <Input
                        id="admin-name"
                        value={newAdmin.name}
                        onChange={(e) => setNewAdmin({ ...newAdmin, name: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="admin-email">Email</Label>
                      <Input
                        id="admin-email"
                        type="email"
                        value={newAdmin.email}
                        onChange={(e) => setNewAdmin({ ...newAdmin, email: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="admin-password">Password</Label>
                      <Input
                        id="admin-password"
                        type="password"
                        value={newAdmin.password}
                        onChange={(e) => setNewAdmin({ ...newAdmin, password: e.target.value })}
                      />
                    </div>
                    <Button onClick={handleAddAdmin} className="w-full">
                      Tambah Admin
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>

              <Dialog open={showChangePassword} onOpenChange={setShowChangePassword}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="flex items-center space-x-2 bg-transparent">
                    <Key className="w-4 h-4" />
                    <span>Ganti Password</span>
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Ganti Password</DialogTitle>
                    <DialogDescription>Ubah password akun admin</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="current-password">Password Saat Ini</Label>
                      <Input
                        id="current-password"
                        type="password"
                        value={passwordChange.current}
                        onChange={(e) => setPasswordChange({ ...passwordChange, current: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="new-password">Password Baru</Label>
                      <Input
                        id="new-password"
                        type="password"
                        value={passwordChange.new}
                        onChange={(e) => setPasswordChange({ ...passwordChange, new: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="confirm-password">Konfirmasi Password Baru</Label>
                      <Input
                        id="confirm-password"
                        type="password"
                        value={passwordChange.confirm}
                        onChange={(e) => setPasswordChange({ ...passwordChange, confirm: e.target.value })}
                      />
                    </div>
                    <Button onClick={handleChangePassword} className="w-full">
                      Ganti Password
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>

              <Button variant="outline" onClick={handleLogout} className="flex items-center space-x-2 bg-transparent">
                <LogOut className="w-4 h-4" />
                <span>Keluar</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-7">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="teachers">Guru</TabsTrigger>
            <TabsTrigger value="users">Pengguna</TabsTrigger>
            <TabsTrigger value="questions">Pertanyaan</TabsTrigger>
            <TabsTrigger value="testimonials">Testimoni</TabsTrigger>
            <TabsTrigger value="careers">Karier</TabsTrigger>
            <TabsTrigger value="reports">Laporan</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Stats Cards */}
            <div className="grid md:grid-cols-4 gap-6">
              <Card className="border-0 shadow-md">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                      <Users className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-gray-900">{totalUsers}</p>
                      <p className="text-sm text-gray-600">Total Siswa</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-md">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                      <GraduationCap className="w-6 h-6 text-green-600" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-gray-900">{totalTeachers}</p>
                      <p className="text-sm text-gray-600">Guru Aktif</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-md">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
                      <FileText className="w-6 h-6 text-orange-600" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-gray-900">{testResults.length}</p>
                      <p className="text-sm text-gray-600">Tes Selesai</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-md">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center">
                      <Settings className="w-6 h-6 text-red-600" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-gray-900">{pendingTeachers}</p>
                      <p className="text-sm text-gray-600">Persetujuan Pending</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Charts */}
            <div className="grid lg:grid-cols-2 gap-8">
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle>Distribusi Tipe RIASEC</CardTitle>
                  <CardDescription>Jumlah siswa per tipe dominan</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={riasecDistribution}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="type" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="count" fill="#8884d8" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle>Tren Bulanan</CardTitle>
                  <CardDescription>Jumlah tes per bulan</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={monthlyTrend}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip />
                        <Line type="monotone" dataKey="tests" stroke="#8884d8" strokeWidth={2} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activities */}
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Aktivitas Terbaru</CardTitle>
                <CardDescription>Ringkasan aktivitas platform dalam 7 hari terakhir</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                    <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                      <Users className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <p className="font-medium">
                        {
                          users.filter((u) => {
                            const regDate = new Date(u.registrationDate)
                            const weekAgo = new Date()
                            weekAgo.setDate(weekAgo.getDate() - 7)
                            return regDate > weekAgo
                          }).length
                        }{" "}
                        siswa baru mendaftar
                      </p>
                      <p className="text-sm text-gray-600">7 hari terakhir</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                    <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                      <Check className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <p className="font-medium">
                        {teachers.filter((t) => t.status === "approved").length} guru disetujui
                      </p>
                      <p className="text-sm text-gray-600">Total guru aktif</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 bg-purple-50 rounded-lg">
                    <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center">
                      <FileText className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <p className="font-medium">{testResults.length} tes diselesaikan</p>
                      <p className="text-sm text-gray-600">Total tes yang telah dikerjakan</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Teachers Tab */}
          <TabsContent value="teachers" className="space-y-6">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>Kelola Akun Guru</CardTitle>
                    <CardDescription>Setujui, tolak, atau hapus akun guru dengan masa aktif 1 tahun</CardDescription>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Filter className="w-4 h-4 text-gray-500" />
                    <Select value={teacherStatusFilter} onValueChange={setTeacherStatusFilter}>
                      <SelectTrigger className="w-48">
                        <SelectValue placeholder="Filter Status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Semua Status</SelectItem>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="approved">Disetujui</SelectItem>
                        <SelectItem value="rejected">Ditolak</SelectItem>
                        <SelectItem value="warning">Segera Berakhir</SelectItem>
                        <SelectItem value="expired">Berakhir</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-3 px-4">Nama</th>
                        <th className="text-left py-3 px-4">Email</th>
                        <th className="text-left py-3 px-4">Sekolah</th>
                        <th className="text-left py-3 px-4">Status</th>
                        <th className="text-left py-3 px-4">Masa Aktif</th>
                        <th className="text-left py-3 px-4">Tanggal Daftar</th>
                        <th className="text-center py-3 px-4">Aksi</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredTeachers.map((teacher) => (
                        <tr key={teacher.id} className="border-b hover:bg-gray-50">
                          <td className="py-4 px-4 font-medium">{teacher.name}</td>
                          <td className="py-4 px-4 text-sm text-gray-600">{teacher.email}</td>
                          <td className="py-4 px-4 text-sm text-gray-600">{teacher.school}</td>
                          <td className="py-4 px-4">
                            <Badge className={`${getStatusBadgeColor(teacher)} border`}>{getStatusText(teacher)}</Badge>
                          </td>
                          <td className="py-4 px-4 text-sm text-gray-600">
                            {teacher.subscriptionEnd ? (
                              <div>
                                <p>{new Date(teacher.subscriptionEnd).toLocaleDateString("id-ID")}</p>
                                <p className="text-xs text-gray-500">
                                  {teacher.status === "approved" &&
                                    `${Math.max(0, Math.ceil((new Date(teacher.subscriptionEnd).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)))} hari lagi`}
                                </p>
                              </div>
                            ) : (
                              "-"
                            )}
                          </td>
                          <td className="py-4 px-4 text-sm text-gray-600">
                            {new Date(teacher.registrationDate).toLocaleDateString("id-ID")}
                          </td>
                          <td className="py-4 px-4">
                            <div className="flex space-x-2 justify-center">
                              {teacher.status === "pending" && (
                                <>
                                  <Button
                                    size="sm"
                                    onClick={() => approveTeacher(teacher.id)}
                                    className="bg-green-600 hover:bg-green-700"
                                    title="Setujui (Masa aktif 1 tahun)"
                                  >
                                    <Check className="w-4 h-4" />
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="destructive"
                                    onClick={() => rejectTeacher(teacher.id)}
                                    title="Tolak"
                                  >
                                    <X className="w-4 h-4" />
                                  </Button>
                                </>
                              )}
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleDeleteTeacher(teacher.id)}
                                title="Hapus"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {filteredTeachers.length === 0 && (
                  <div className="text-center py-8">
                    <p className="text-gray-500">Tidak ada data guru yang sesuai filter</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-6">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>Kelola Pengguna</CardTitle>
                    <CardDescription>Daftar semua pengguna yang terdaftar</CardDescription>
                  </div>
                  <Button
                    onClick={() => {
                      const reportData = schoolFilteredUsers.map((user) => ({
                        Nama: user.name,
                        Email: user.email,
                        Sekolah: user.school || "",
                        "Tanggal Daftar": new Date(user.registrationDate).toLocaleDateString("id-ID"),
                        "Terakhir Aktif": new Date(user.lastActive).toLocaleDateString("id-ID"),
                      }))
                      exportToCSV(
                        reportData,
                        `laporan_pengguna_${selectedSchool === "all" ? "semua" : selectedSchool}_${new Date().toISOString().split("T")[0]}.csv`,
                      )
                    }}
                    className="flex items-center space-x-2"
                  >
                    <Download className="w-4 h-4" />
                    <span>Export Laporan</span>
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {/* Filters */}
                <div className="flex flex-col sm:flex-row gap-4 mb-6">
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <Input
                        placeholder="Cari nama siswa atau sekolah..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                  </div>
                  <Select value={selectedSchool} onValueChange={setSelectedSchool}>
                    <SelectTrigger className="w-full sm:w-64">
                      <SelectValue placeholder="Pilih Sekolah" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Semua Sekolah</SelectItem>
                      {schools.map((school) => (
                        <SelectItem key={school} value={school}>
                          {school}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-3 px-4">Nama</th>
                        <th className="text-left py-3 px-4">Email</th>
                        <th className="text-left py-3 px-4">Sekolah</th>
                        <th className="text-left py-3 px-4">Tanggal Daftar</th>
                        <th className="text-left py-3 px-4">Terakhir Aktif</th>
                        <th className="text-center py-3 px-4">Aksi</th>
                      </tr>
                    </thead>
                    <tbody>
                      {schoolFilteredUsers.map((user) => (
                        <tr key={user.id} className="border-b hover:bg-gray-50">
                          <td className="py-4 px-4 font-medium">{user.name}</td>
                          <td className="py-4 px-4 text-sm text-gray-600">{user.email}</td>
                          <td className="py-4 px-4 text-sm text-gray-600">{user.school || "Tidak diisi"}</td>
                          <td className="py-4 px-4 text-sm text-gray-600">
                            {new Date(user.registrationDate).toLocaleDateString("id-ID")}
                          </td>
                          <td className="py-4 px-4 text-sm text-gray-600">
                            {new Date(user.lastActive).toLocaleDateString("id-ID")}
                          </td>
                          <td className="py-4 px-4 text-center">
                            <Button size="sm" variant="destructive" onClick={() => handleDeleteUser(user.id)}>
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {schoolFilteredUsers.length === 0 && (
                  <div className="text-center py-8">
                    <p className="text-gray-500">Tidak ada data pengguna yang ditemukan</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Questions Tab */}
          <TabsContent value="questions" className="space-y-6">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>Kelola Pertanyaan Tes</CardTitle>
                    <CardDescription>Edit, tambah, atau nonaktifkan pertanyaan tes RIASEC</CardDescription>
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="outline" onClick={generateQuestionTemplate}>
                      <Download className="w-4 h-4 mr-2" />
                      Template CSV
                    </Button>
                    <div className="relative">
                      <Input
                        type="file"
                        accept=".csv"
                        onChange={handleUploadCSV}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                      />
                      <Button className="flex items-center space-x-2">
                        <Upload className="w-4 h-4" />
                        <span>Upload CSV</span>
                      </Button>
                    </div>
                    <Dialog open={showAddQuestion} onOpenChange={setShowAddQuestion}>
                      <DialogTrigger asChild>
                        <Button className="flex items-center space-x-2">
                          <Plus className="w-4 h-4" />
                          <span>Tambah Pertanyaan</span>
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Tambah Pertanyaan Baru</DialogTitle>
                          <DialogDescription>Buat pertanyaan tes RIASEC baru</DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="question-bagian">Bagian</Label>
                            <Select
                              value={newQuestion.bagian.toString()}
                              onValueChange={(value) =>
                                setNewQuestion({ ...newQuestion, bagian: Number.parseInt(value) })
                              }
                            >
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="1">Bagian 1</SelectItem>
                                <SelectItem value="2">Bagian 2</SelectItem>
                                <SelectItem value="3">Bagian 3</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label htmlFor="question-type">Tipe RIASEC</Label>
                            <Select
                              value={newQuestion.type}
                              onValueChange={(value) => setNewQuestion({ ...newQuestion, type: value as any })}
                            >
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="R">R - Realistic</SelectItem>
                                <SelectItem value="I">I - Investigative</SelectItem>
                                <SelectItem value="A">A - Artistic</SelectItem>
                                <SelectItem value="S">S - Social</SelectItem>
                                <SelectItem value="E">E - Enterprising</SelectItem>
                                <SelectItem value="C">C - Conventional</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label htmlFor="question-text">Teks Pertanyaan</Label>
                            <Textarea
                              id="question-text"
                              value={newQuestion.text}
                              onChange={(e) => setNewQuestion({ ...newQuestion, text: e.target.value })}
                              rows={3}
                            />
                          </div>
                          <Button onClick={handleAddQuestion} className="w-full">
                            Tambah Pertanyaan
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {questions.map((question) => (
                    <div key={question.id} className="p-4 border rounded-lg">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <Badge variant="outline">Bagian {question.bagian}</Badge>
                            <Badge
                              variant="secondary"
                              style={{
                                backgroundColor: `${
                                  question.type === "R"
                                    ? "#ef4444"
                                    : question.type === "I"
                                      ? "#3b82f6"
                                      : question.type === "A"
                                        ? "#8b5cf6"
                                        : question.type === "S"
                                          ? "#10b981"
                                          : question.type === "E"
                                            ? "#f59e0b"
                                            : "#6366f1"
                                }20`,
                                color:
                                  question.type === "R"
                                    ? "#ef4444"
                                    : question.type === "I"
                                      ? "#3b82f6"
                                      : question.type === "A"
                                        ? "#8b5cf6"
                                        : question.type === "S"
                                          ? "#10b981"
                                          : question.type === "E"
                                            ? "#f59e0b"
                                            : "#6366f1",
                              }}
                            >
                              Tipe {question.type}
                            </Badge>
                            <Badge variant={question.isActive ? "default" : "secondary"}>
                              {question.isActive ? "Aktif" : "Nonaktif"}
                            </Badge>
                          </div>
                          <p className="text-gray-900">{question.text}</p>
                        </div>
                        <div className="flex items-center space-x-2 ml-4">
                          <Switch
                            checked={question.isActive}
                            onCheckedChange={() => {
                              const updatedQuestions = questions.map((q) =>
                                q.id === question.id ? { ...q, isActive: !q.isActive } : q,
                              )
                              setQuestions(updatedQuestions)
                              localStorage.setItem("customQuestions", JSON.stringify(updatedQuestions))
                            }}
                          />
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button size="sm" variant="outline" onClick={() => setEditingQuestion(question)}>
                                <Edit className="w-4 h-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Edit Pertanyaan</DialogTitle>
                                <DialogDescription>Ubah pertanyaan tes RIASEC</DialogDescription>
                              </DialogHeader>
                              {editingQuestion && (
                                <div className="space-y-4">
                                  <div>
                                    <Label>Bagian</Label>
                                    <Select
                                      value={editingQuestion.bagian.toString()}
                                      onValueChange={(value) =>
                                        setEditingQuestion({ ...editingQuestion, bagian: Number.parseInt(value) })
                                      }
                                    >
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="1">Bagian 1</SelectItem>
                                        <SelectItem value="2">Bagian 2</SelectItem>
                                        <SelectItem value="3">Bagian 3</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </div>
                                  <div>
                                    <Label>Tipe RIASEC</Label>
                                    <Select
                                      value={editingQuestion.type}
                                      onValueChange={(value) => setEditingQuestion({ ...editingQuestion, type: value })}
                                    >
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="R">R - Realistic</SelectItem>
                                        <SelectItem value="I">I - Investigative</SelectItem>
                                        <SelectItem value="A">A - Artistic</SelectItem>
                                        <SelectItem value="S">S - Social</SelectItem>
                                        <SelectItem value="E">E - Enterprising</SelectItem>
                                        <SelectItem value="C">C - Conventional</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </div>
                                  <div>
                                    <Label>Teks Pertanyaan</Label>
                                    <Textarea
                                      value={editingQuestion.text}
                                      onChange={(e) => setEditingQuestion({ ...editingQuestion, text: e.target.value })}
                                      rows={3}
                                    />
                                  </div>
                                  <Button onClick={() => handleEditQuestion(editingQuestion)} className="w-full">
                                    Simpan Perubahan
                                  </Button>
                                </div>
                              )}
                            </DialogContent>
                          </Dialog>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => {
                              if (confirm("Apakah Anda yakin ingin menghapus pertanyaan ini?")) {
                                const updatedQuestions = questions.filter((q) => q.id !== question.id)
                                setQuestions(updatedQuestions)
                                localStorage.setItem("customQuestions", JSON.stringify(updatedQuestions))
                              }
                            }}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Testimonials Tab */}
          <TabsContent value="testimonials" className="space-y-6">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>Kelola Testimoni</CardTitle>
                    <CardDescription>Tambah, edit, dan kelola testimoni untuk halaman beranda</CardDescription>
                  </div>
                  <Dialog open={showAddTestimonial} onOpenChange={setShowAddTestimonial}>
                    <DialogTrigger asChild>
                      <Button className="flex items-center space-x-2">
                        <MessageSquare className="w-4 h-4" />
                        <span>Tambah Testimoni</span>
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Tambah Testimoni Baru</DialogTitle>
                        <DialogDescription>Buat testimoni untuk ditampilkan di halaman beranda</DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="testimonial-name">Nama</Label>
                          <Input
                            id="testimonial-name"
                            value={newTestimonial.name}
                            onChange={(e) => setNewTestimonial({ ...newTestimonial, name: e.target.value })}
                          />
                        </div>
                        <div>
                          <Label htmlFor="testimonial-role">Peran</Label>
                          <Input
                            id="testimonial-role"
                            value={newTestimonial.role}
                            onChange={(e) => setNewTestimonial({ ...newTestimonial, role: e.target.value })}
                            placeholder="Siswa SMA / Guru BK / dll"
                          />
                        </div>
                        <div>
                          <Label htmlFor="testimonial-school">Sekolah</Label>
                          <Input
                            id="testimonial-school"
                            value={newTestimonial.school}
                            onChange={(e) => setNewTestimonial({ ...newTestimonial, school: e.target.value })}
                          />
                        </div>
                        <div>
                          <Label htmlFor="testimonial-content">Isi Testimoni</Label>
                          <Textarea
                            id="testimonial-content"
                            value={newTestimonial.content}
                            onChange={(e) => setNewTestimonial({ ...newTestimonial, content: e.target.value })}
                            rows={4}
                          />
                        </div>
                        <div>
                          <Label htmlFor="testimonial-rating">Rating (1-5)</Label>
                          <Select
                            value={newTestimonial.rating.toString()}
                            onValueChange={(value) =>
                              setNewTestimonial({ ...newTestimonial, rating: Number.parseInt(value) })
                            }
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="5">5 Bintang</SelectItem>
                              <SelectItem value="4">4 Bintang</SelectItem>
                              <SelectItem value="3">3 Bintang</SelectItem>
                              <SelectItem value="2">2 Bintang</SelectItem>
                              <SelectItem value="1">1 Bintang</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <Button onClick={handleAddTestimonial} className="w-full">
                          Tambah Testimoni
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {testimonials.map((testimonial) => (
                    <div key={testimonial.id} className="p-4 border rounded-lg">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <Badge variant={testimonial.isActive ? "default" : "secondary"}>
                              {testimonial.isActive ? "Aktif" : "Nonaktif"}
                            </Badge>
                            <div className="flex text-yellow-400">
                              {[...Array(testimonial.rating)].map((_, i) => (
                                <Star key={i} className="w-4 h-4 fill-current" />
                              ))}
                            </div>
                          </div>
                          <p className="text-gray-900 mb-2 italic">"{testimonial.content}"</p>
                          <div className="text-sm text-gray-600">
                            <p className="font-medium">{testimonial.name}</p>
                            <p>
                              {testimonial.role} - {testimonial.school}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2 ml-4">
                          <Switch
                            checked={testimonial.isActive}
                            onCheckedChange={() => {
                              const updatedTestimonial = { ...testimonial, isActive: !testimonial.isActive }
                              saveTestimonial(updatedTestimonial)
                              loadData()
                            }}
                          />
                          <Dialog open={showEditTestimonial} onOpenChange={setShowEditTestimonial}>
                            <DialogTrigger asChild>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => {
                                  setEditingTestimonial(testimonial)
                                  setShowEditTestimonial(true)
                                }}
                              >
                                <Edit className="w-4 h-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Edit Testimoni</DialogTitle>
                                <DialogDescription>Ubah testimoni yang ada</DialogDescription>
                              </DialogHeader>
                              {editingTestimonial && (
                                <div className="space-y-4">
                                  <div>
                                    <Label>Nama</Label>
                                    <Input
                                      value={editingTestimonial.name}
                                      onChange={(e) =>
                                        setEditingTestimonial({ ...editingTestimonial, name: e.target.value })
                                      }
                                    />
                                  </div>
                                  <div>
                                    <Label>Peran</Label>
                                    <Input
                                      value={editingTestimonial.role}
                                      onChange={(e) =>
                                        setEditingTestimonial({ ...editingTestimonial, role: e.target.value })
                                      }
                                    />
                                  </div>
                                  <div>
                                    <Label>Sekolah</Label>
                                    <Input
                                      value={editingTestimonial.school}
                                      onChange={(e) =>
                                        setEditingTestimonial({ ...editingTestimonial, school: e.target.value })
                                      }
                                    />
                                  </div>
                                  <div>
                                    <Label>Isi Testimoni</Label>
                                    <Textarea
                                      value={editingTestimonial.content}
                                      onChange={(e) =>
                                        setEditingTestimonial({ ...editingTestimonial, content: e.target.value })
                                      }
                                      rows={4}
                                    />
                                  </div>
                                  <div>
                                    <Label>Rating</Label>
                                    <Select
                                      value={editingTestimonial.rating.toString()}
                                      onValueChange={(value) =>
                                        setEditingTestimonial({
                                          ...editingTestimonial,
                                          rating: Number.parseInt(value),
                                        })
                                      }
                                    >
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="5">5 Bintang</SelectItem>
                                        <SelectItem value="4">4 Bintang</SelectItem>
                                        <SelectItem value="3">3 Bintang</SelectItem>
                                        <SelectItem value="2">2 Bintang</SelectItem>
                                        <SelectItem value="1">1 Bintang</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </div>
                                  <Button onClick={handleEditTestimonial} className="w-full">
                                    Simpan Perubahan
                                  </Button>
                                </div>
                              )}
                            </DialogContent>
                          </Dialog>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => {
                              if (confirm("Apakah Anda yakin ingin menghapus testimoni ini?")) {
                                deleteTestimonial(testimonial.id)
                                loadData()
                              }
                            }}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                {testimonials.length === 0 && (
                  <div className="text-center py-8">
                    <p className="text-gray-500">Belum ada testimoni. Tambahkan testimoni pertama!</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Careers Tab */}
          <TabsContent value="careers" className="space-y-6">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>Database Saran Karier</CardTitle>
                    <CardDescription>Kelola saran karier berdasarkan tipe RIASEC dominan</CardDescription>
                  </div>
                  <Dialog open={showAddCareer} onOpenChange={setShowAddCareer}>
                    <DialogTrigger asChild>
                      <Button className="flex items-center space-x-2">
                        <Briefcase className="w-4 h-4" />
                        <span>Tambah Karier</span>
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Tambah Saran Karier</DialogTitle>
                        <DialogDescription>Buat saran karier baru untuk tipe RIASEC tertentu</DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="career-type">Tipe RIASEC</Label>
                          <Select
                            value={newCareer.type}
                            onValueChange={(value) => setNewCareer({ ...newCareer, type: value as any })}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="R">R - Realistic</SelectItem>
                              <SelectItem value="I">I - Investigative</SelectItem>
                              <SelectItem value="A">A - Artistic</SelectItem>
                              <SelectItem value="S">S - Social</SelectItem>
                              <SelectItem value="E">E - Enterprising</SelectItem>
                              <SelectItem value="C">C - Conventional</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="career-name">Nama Karier</Label>
                          <Input
                            id="career-name"
                            value={newCareer.career}
                            onChange={(e) => setNewCareer({ ...newCareer, career: e.target.value })}
                          />
                        </div>
                        <div>
                          <Label htmlFor="career-description">Deskripsi</Label>
                          <Textarea
                            id="career-description"
                            value={newCareer.description}
                            onChange={(e) => setNewCareer({ ...newCareer, description: e.target.value })}
                            rows={3}
                          />
                        </div>
                        <div>
                          <Label htmlFor="career-match">Persentase Match (%)</Label>
                          <Input
                            id="career-match"
                            type="number"
                            min="1"
                            max="100"
                            value={newCareer.matchPercentage}
                            onChange={(e) =>
                              setNewCareer({ ...newCareer, matchPercentage: Number.parseInt(e.target.value) })
                            }
                          />
                        </div>
                        <Button onClick={handleAddCareer} className="w-full">
                          Tambah Karier
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {["R", "I", "A", "S", "E", "C"].map((type) => (
                    <div key={type} className="border rounded-lg p-4">
                      <h3 className="font-semibold text-lg mb-3 flex items-center">
                        <div
                          className="w-8 h-8 rounded-lg flex items-center justify-center text-white font-bold mr-3"
                          style={{
                            backgroundColor:
                              type === "R"
                                ? "#ef4444"
                                : type === "I"
                                  ? "#3b82f6"
                                  : type === "A"
                                    ? "#8b5cf6"
                                    : type === "S"
                                      ? "#10b981"
                                      : type === "E"
                                        ? "#f59e0b"
                                        : "#6366f1",
                          }}
                        >
                          {type}
                        </div>
                        Tipe {type} -{" "}
                        {type === "R"
                          ? "Realistic"
                          : type === "I"
                            ? "Investigative"
                            : type === "A"
                              ? "Artistic"
                              : type === "S"
                                ? "Social"
                                : type === "E"
                                  ? "Enterprising"
                                  : "Conventional"}
                      </h3>
                      <div className="grid gap-3">
                        {careerSuggestions
                          .filter((career) => career.type === type)
                          .map((career) => (
                            <div
                              key={career.id}
                              className="flex justify-between items-center p-3 bg-gray-50 rounded-lg"
                            >
                              <div className="flex-1">
                                <div className="flex items-center space-x-2 mb-1">
                                  <h4 className="font-medium">{career.career}</h4>
                                  <Badge variant="outline">{career.matchPercentage}% match</Badge>
                                  <Badge variant={career.isActive ? "default" : "secondary"}>
                                    {career.isActive ? "Aktif" : "Nonaktif"}
                                  </Badge>
                                </div>
                                <p className="text-sm text-gray-600">{career.description}</p>
                              </div>
                              <div className="flex items-center space-x-2 ml-4">
                                <Switch
                                  checked={career.isActive}
                                  onCheckedChange={() => {
                                    const updatedCareer = { ...career, isActive: !career.isActive }
                                    saveCareerSuggestion(updatedCareer)
                                    loadData()
                                  }}
                                />
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  onClick={() => {
                                    if (confirm("Apakah Anda yakin ingin menghapus saran karier ini?")) {
                                      deleteCareerSuggestion(career.id)
                                      loadData()
                                    }
                                  }}
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </div>
                          ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Reports Tab */}
          <TabsContent value="reports" className="space-y-6">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Laporan & Export</CardTitle>
                <CardDescription>Download laporan dan export data platform</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="font-semibold">Export Data</h3>
                    <div className="space-y-3">
                      <Button
                        variant="outline"
                        className="w-full justify-start bg-transparent"
                        onClick={() => {
                          const reportData = schoolFilteredUsers.map((user) => ({
                            Nama: user.name,
                            Email: user.email,
                            Sekolah: user.school || "",
                            "Tanggal Daftar": new Date(user.registrationDate).toLocaleDateString("id-ID"),
                            "Terakhir Aktif": new Date(user.lastActive).toLocaleDateString("id-ID"),
                          }))
                          exportToCSV(
                            reportData,
                            `data_siswa_${selectedSchool === "all" ? "semua" : selectedSchool}_${new Date().toISOString().split("T")[0]}.csv`,
                          )
                        }}
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Export Data Siswa (CSV)
                      </Button>
                      <Button
                        variant="outline"
                        className="w-full justify-start bg-transparent"
                        onClick={() => {
                          const teacherData = teachers.map((t) => ({
                            Nama: t.name,
                            Email: t.email,
                            Sekolah: t.school || "",
                            Status: t.status,
                            "Tanggal Daftar": new Date(t.registrationDate).toLocaleDateString("id-ID"),
                          }))
                          exportToCSV(teacherData, `data_guru_${new Date().toISOString().split("T")[0]}.csv`)
                        }}
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Export Data Guru (CSV)
                      </Button>
                      <Button
                        variant="outline"
                        className="w-full justify-start bg-transparent"
                        onClick={() => {
                          const reportData = testResults.map((result) => ({
                            Nama: result.userName,
                            Sekolah: result.userSchool,
                            "Tanggal Tes": new Date(result.date).toLocaleDateString("id-ID"),
                            "Skor R": result.scores.R,
                            "Skor I": result.scores.I,
                            "Skor A": result.scores.A,
                            "Skor S": result.scores.S,
                            "Skor E": result.scores.E,
                            "Skor C": result.scores.C,
                            "Tipe Dominan 1": result.dominantTypes[0] || "",
                            "Tipe Dominan 2": result.dominantTypes[1] || "",
                            "Tipe Dominan 3": result.dominantTypes[2] || "",
                          }))
                          exportToCSV(reportData, `hasil_tes_${new Date().toISOString().split("T")[0]}.csv`)
                        }}
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Export Hasil Tes (CSV)
                      </Button>
                      <Button
                        variant="outline"
                        className="w-full justify-start bg-transparent"
                        onClick={() => {
                          const allData = {
                            users: users,
                            teachers: teachers,
                            testResults: testResults,
                            questions: questions,
                            testimonials: testimonials,
                            careerSuggestions: careerSuggestions,
                          }
                          const blob = new Blob([JSON.stringify(allData, null, 2)], { type: "application/json" })
                          const url = URL.createObjectURL(blob)
                          const link = document.createElement("a")
                          link.href = url
                          link.download = `database_lengkap_${new Date().toISOString().split("T")[0]}.json`
                          link.click()
                        }}
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Export Database Lengkap
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="font-semibold">Laporan Analitik</h3>
                    <div className="space-y-3">
                      <Button
                        variant="outline"
                        className="w-full justify-start bg-transparent"
                        onClick={() => exportAnalyticsReport("excel")}
                      >
                        <BarChart3 className="w-4 h-4 mr-2" />
                        Laporan Analytics (Excel)
                      </Button>
                      <Button
                        variant="outline"
                        className="w-full justify-start bg-transparent"
                        onClick={() => exportAnalyticsReport("pdf")}
                      >
                        <BarChart3 className="w-4 h-4 mr-2" />
                        Laporan Analytics (PDF)
                      </Button>
                      <Button
                        variant="outline"
                        className="w-full justify-start bg-transparent"
                        onClick={() => {
                          const monthlyData = testResults.reduce(
                            (acc, result) => {
                              const month = new Date(result.date).toLocaleDateString("id-ID", {
                                year: "numeric",
                                month: "long",
                              })
                              acc[month] = (acc[month] || 0) + 1
                              return acc
                            },
                            {} as { [key: string]: number },
                          )

                          const reportData = Object.entries(monthlyData).map(([month, count]) => ({
                            Bulan: month,
                            "Jumlah Tes": count,
                          }))

                          exportToCSV(reportData, `laporan_bulanan_${new Date().toISOString().split("T")[0]}.csv`)
                        }}
                      >
                        <BarChart3 className="w-4 h-4 mr-2" />
                        Laporan Bulanan
                      </Button>
                      <Button
                        variant="outline"
                        className="w-full justify-start bg-transparent"
                        onClick={() => {
                          const riasecData = ["R", "I", "A", "S", "E", "C"].map((type) => ({
                            Tipe: type,
                            "Jumlah Dominan": testResults.filter((r) => r.dominantTypes[0] === type).length,
                            "Rata-rata Skor":
                              testResults.length > 0
                                ? (
                                    testResults.reduce((sum, r) => sum + r.scores[type as keyof typeof r.scores], 0) /
                                    testResults.length
                                  ).toFixed(2)
                                : "0",
                          }))

                          exportToCSV(riasecData, `analisis_tren_riasec_${new Date().toISOString().split("T")[0]}.csv`)
                        }}
                      >
                        <BarChart3 className="w-4 h-4 mr-2" />
                        Analisis Tren RIASEC
                      </Button>
                      <Button
                        variant="outline"
                        className="w-full justify-start bg-transparent"
                        onClick={() => {
                          const schoolStats = schools.map((school) => ({
                            Sekolah: school,
                            "Jumlah Siswa": users.filter((u) => u.school === school).length,
                            "Jumlah Tes": testResults.filter((r) => r.userSchool === school).length,
                            "Guru Aktif": teachers.filter((t) => t.school === school && t.status === "approved").length,
                          }))
                          exportToCSV(schoolStats, `statistik_sekolah_${new Date().toISOString().split("T")[0]}.csv`)
                        }}
                      >
                        <BarChart3 className="w-4 h-4 mr-2" />
                        Statistik Sekolah
                      </Button>
                      <Button
                        variant="outline"
                        className="w-full justify-start bg-transparent"
                        onClick={() => {
                          const performanceData = [
                            {
                              "Total Pengguna": users.length,
                              "Total Guru": teachers.length,
                              "Tes Diselesaikan": testResults.length,
                              "Pertanyaan Aktif": questions.filter((q) => q.isActive).length,
                              "Guru Pending": teachers.filter((t) => t.status === "pending").length,
                              "Tanggal Laporan": new Date().toLocaleDateString("id-ID"),
                            },
                          ]
                          exportToCSV(performanceData, `kinerja_platform_${new Date().toISOString().split("T")[0]}.csv`)
                        }}
                      >
                        <BarChart3 className="w-4 h-4 mr-2" />
                        Laporan Kinerja Platform
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
