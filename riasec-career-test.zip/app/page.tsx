import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Star, Award, TrendingUp, CheckCircle, Quote, GraduationCap, School } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
                <Award className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">RIASEC Career Test</h1>
                <p className="text-sm text-gray-500">Temukan Minat Kariermu</p>
              </div>
            </div>
            <div className="flex space-x-3">
              <Link href="/login">
                <Button variant="outline">Masuk</Button>
              </Link>
              <Link href="/register">
                <Button>Daftar</Button>
              </Link>
              <Link href="/login/super-admin">
                <Button variant="ghost" className="text-xs">
                  Super Admin
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Temukan{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">Passion</span>{" "}
            Kariermu
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Platform tes RIASEC terdepan yang telah membantu ribuan siswa menemukan jalur karier yang tepat dengan
            akurasi tinggi dan analisis mendalam
          </p>
          <Link href="/register">
            <Button
              size="lg"
              className="text-lg px-8 py-4 rounded-2xl bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
            >
              Mulai Tes Gratis Sekarang
            </Button>
          </Link>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h3 className="text-3xl font-bold text-center text-gray-900 mb-4">Mengapa Memilih Platform Kami?</h3>
          <p className="text-center text-gray-600 mb-12 max-w-3xl mx-auto">
            Dapatkan insight mendalam tentang minat karier dengan teknologi terdepan dan analisis yang komprehensif
          </p>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="w-8 h-8 text-blue-600" />
              </div>
              <h4 className="text-xl font-bold mb-2">Akurasi Tinggi</h4>
              <p className="text-gray-600">
                Algoritma canggih dengan tingkat akurasi 95% berdasarkan penelitian terbaru
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
              <h4 className="text-xl font-bold mb-2">Hasil Instan</h4>
              <p className="text-gray-600">Dapatkan laporan lengkap dengan visualisasi menarik dalam hitungan detik</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="w-8 h-8 text-purple-600" />
              </div>
              <h4 className="text-xl font-bold mb-2">Sertifikat Resmi</h4>
              <p className="text-gray-600">Hasil tes dapat digunakan untuk keperluan akademik dan profesional</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <h3 className="text-3xl font-bold text-center text-gray-900 mb-12">Solusi Lengkap untuk Semua</h3>
          <div className="grid md:grid-cols-2 gap-8">
            {/* For Students */}
            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow rounded-2xl">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <BookOpen className="w-8 h-8 text-blue-600" />
                </div>
                <CardTitle className="text-xl">Untuk Siswa</CardTitle>
                <CardDescription>Temukan passion dan bakat terpendam dengan tes yang menyenangkan</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="bg-blue-50 p-4 rounded-xl">
                    <h5 className="font-semibold text-blue-900 mb-2">🎯 Keuntungan untuk Siswa:</h5>
                    <ul className="text-sm text-blue-800 space-y-1">
                      <li>• Mengetahui minat dan bakat sejak dini</li>
                      <li>• Panduan memilih jurusan kuliah yang tepat</li>
                      <li>• Rekomendasi karier masa depan</li>
                      <li>• Meningkatkan kepercayaan diri</li>
                      <li>• Laporan PDF profesional untuk portofolio</li>
                    </ul>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-2xl font-bold text-blue-600">196</p>
                      <p className="text-xs text-gray-600">Pertanyaan Komprehensif</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-2xl font-bold text-green-600">6</p>
                      <p className="text-xs text-gray-600">Tipe Kepribadian</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* For Teachers & Schools Combined */}
            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow rounded-2xl relative">
              <div className="absolute -top-3 -right-3">
                <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-3 py-1">
                  <Star className="w-3 h-3 mr-1" />
                  PREMIUM
                </Badge>
              </div>
              <CardHeader className="text-center pb-4">
                <div className="flex justify-center space-x-2 mb-4">
                  <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                    <GraduationCap className="w-6 h-6 text-green-600" />
                  </div>
                  <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                    <School className="w-6 h-6 text-purple-600" />
                  </div>
                </div>
                <CardTitle className="text-xl">Untuk Guru & Sekolah</CardTitle>
                <CardDescription>Dashboard analytics lengkap untuk monitoring dan evaluasi siswa</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="bg-green-50 p-4 rounded-xl">
                    <h5 className="font-semibold text-green-900 mb-2 flex items-center">
                      <GraduationCap className="w-4 h-4 mr-2" />
                      Keuntungan untuk Guru:
                    </h5>
                    <ul className="text-sm text-green-800 space-y-1">
                      <li>• Memahami karakteristik setiap siswa</li>
                      <li>• Data untuk bimbingan konseling yang efektif</li>
                      <li>• Laporan komprehensif untuk orang tua</li>
                      <li>• Analytics dan tren minat siswa</li>
                      <li>• Export data dalam berbagai format</li>
                    </ul>
                  </div>
                  <div className="bg-purple-50 p-4 rounded-xl">
                    <h5 className="font-semibold text-purple-900 mb-2 flex items-center">
                      <School className="w-4 h-4 mr-2" />
                      Keuntungan untuk Sekolah:
                    </h5>
                    <ul className="text-sm text-purple-800 space-y-1">
                      <li>• Meningkatkan kualitas bimbingan karier</li>
                      <li>• Data untuk pengembangan kurikulum</li>
                      <li>• Laporan untuk akreditasi sekolah</li>
                      <li>• Branding sekolah yang inovatif</li>
                      <li>• Dashboard monitoring real-time</li>
                    </ul>
                  </div>
                  <div className="bg-gradient-to-r from-green-100 to-purple-100 p-3 rounded-xl text-center">
                    <p className="text-sm font-medium text-gray-800">🏆 Solusi Terpadu untuk Ekosistem Pendidikan</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Sample Results */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h3 className="text-3xl font-bold text-center text-gray-900 mb-12">Contoh Hasil Tes yang Menakjubkan</h3>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-gradient-to-br from-blue-50 to-purple-50 p-6 rounded-2xl">
              <h4 className="text-xl font-bold mb-4">📊 Visualisasi Data Interaktif</h4>
              <div className="bg-white p-4 rounded-xl shadow-sm">
                <div className="flex justify-center items-center h-32">
                  <div className="text-center">
                    <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-2">
                      <span className="text-white font-bold text-lg">S</span>
                    </div>
                    <p className="text-sm font-medium">Social - 85%</p>
                  </div>
                </div>
                <p className="text-xs text-gray-600 text-center mt-2">Radar Chart & Pie Chart Profesional</p>
              </div>
            </div>
            <div className="bg-gradient-to-br from-green-50 to-blue-50 p-6 rounded-2xl">
              <h4 className="text-xl font-bold mb-4">🎯 Rekomendasi Karier Personal</h4>
              <div className="space-y-3">
                <div className="bg-white p-3 rounded-lg shadow-sm">
                  <p className="font-medium text-green-700">🥇 Guru/Pendidik</p>
                  <p className="text-xs text-gray-600">Match: 92%</p>
                </div>
                <div className="bg-white p-3 rounded-lg shadow-sm">
                  <p className="font-medium text-blue-700">🥈 Konselor</p>
                  <p className="text-xs text-gray-600">Match: 88%</p>
                </div>
                <div className="bg-white p-3 rounded-lg shadow-sm">
                  <p className="font-medium text-purple-700">🥉 Psikolog</p>
                  <p className="text-xs text-gray-600">Match: 85%</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <h3 className="text-3xl font-bold text-center text-gray-900 mb-12">Apa Kata Mereka?</h3>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-0 shadow-lg rounded-2xl">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <Quote className="w-8 h-8 text-blue-500 mr-3" />
                  <div className="flex text-yellow-400">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current" />
                    ))}
                  </div>
                </div>
                <p className="text-gray-700 mb-4 italic">
                  "Tes ini benar-benar membantu saya memahami minat saya. Sekarang saya yakin ingin kuliah di jurusan
                  Psikologi!"
                </p>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                    <span className="text-blue-600 font-bold">A</span>
                  </div>
                  <div>
                    <p className="font-semibold">Andi Pratama</p>
                    <p className="text-sm text-gray-600">Siswa SMA Negeri 1</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg rounded-2xl">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <Quote className="w-8 h-8 text-green-500 mr-3" />
                  <div className="flex text-yellow-400">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current" />
                    ))}
                  </div>
                </div>
                <p className="text-gray-700 mb-4 italic">
                  "Platform ini sangat membantu dalam memberikan bimbingan karier kepada siswa. Data yang dihasilkan
                  sangat akurat dan detail."
                </p>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center mr-3">
                    <span className="text-green-600 font-bold">S</span>
                  </div>
                  <div>
                    <p className="font-semibold">Siti Nurhaliza, S.Pd</p>
                    <p className="text-sm text-gray-600">Guru BK SMA Negeri 2</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg rounded-2xl">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <Quote className="w-8 h-8 text-purple-500 mr-3" />
                  <div className="flex text-yellow-400">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current" />
                    ))}
                  </div>
                </div>
                <p className="text-gray-700 mb-4 italic">
                  "Hasil tesnya sangat membantu saya memilih jurusan. Ternyata saya cocok di bidang teknik, dan sekarang
                  saya kuliah Teknik Informatika!"
                </p>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center mr-3">
                    <span className="text-purple-600 font-bold">R</span>
                  </div>
                  <div>
                    <p className="font-semibold">Rizki Maulana</p>
                    <p className="text-sm text-gray-600">Mahasiswa Teknik</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* RIASEC Types */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h3 className="text-3xl font-bold text-center text-gray-900 mb-12">6 Tipe RIASEC</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                type: "R",
                name: "Realistic",
                desc: "Praktis, hands-on, suka bekerja dengan alat dan mesin",
                color: "bg-red-500",
                careers: "Teknisi, Engineer, Pilot",
              },
              {
                type: "I",
                name: "Investigative",
                desc: "Analitis, suka memecahkan masalah dan penelitian",
                color: "bg-blue-500",
                careers: "Ilmuwan, Dokter, Peneliti",
              },
              {
                type: "A",
                name: "Artistic",
                desc: "Kreatif, ekspresif, suka seni dan desain",
                color: "bg-purple-500",
                careers: "Desainer, Musisi, Penulis",
              },
              {
                type: "S",
                name: "Social",
                desc: "Peduli, suka membantu dan berinteraksi dengan orang",
                color: "bg-green-500",
                careers: "Guru, Perawat, Konselor",
              },
              {
                type: "E",
                name: "Enterprising",
                desc: "Ambisius, suka memimpin dan berbisnis",
                color: "bg-orange-500",
                careers: "Manager, Pengusaha, Sales",
              },
              {
                type: "C",
                name: "Conventional",
                desc: "Terorganisir, detail, suka struktur dan aturan",
                color: "bg-indigo-500",
                careers: "Akuntan, Admin, Auditor",
              },
            ].map((item) => (
              <Card key={item.type} className="border-0 shadow-md hover:shadow-lg transition-shadow rounded-2xl">
                <CardHeader className="pb-3">
                  <div className="flex items-center space-x-3">
                    <div className={`w-12 h-12 ${item.color} rounded-xl flex items-center justify-center`}>
                      <span className="text-white font-bold text-lg">{item.type}</span>
                    </div>
                    <div>
                      <CardTitle className="text-lg">{item.name}</CardTitle>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-3">{item.desc}</p>
                  <div className="bg-gray-50 p-2 rounded-lg">
                    <p className="text-xs font-medium text-gray-700">Contoh Karier:</p>
                    <p className="text-xs text-gray-600">{item.careers}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="max-w-4xl mx-auto text-center text-white">
          <h3 className="text-3xl font-bold mb-4">Siap Menemukan Passion Kariermu?</h3>
          <p className="text-xl mb-8 opacity-90">
            Bergabung dengan ribuan siswa yang telah menemukan jalur karier impian mereka
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/register">
              <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 rounded-2xl">
                Mulai Tes Gratis
              </Button>
            </Link>
            <Link href="/login">
              <Button
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-blue-600 px-8 py-4 rounded-2xl bg-transparent"
              >
                Sudah Punya Akun?
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <p className="text-gray-400">Copyright © mgbkpekanbaru - Platform Tes RIASEC Terdepan di Indonesia</p>
        </div>
      </footer>
    </div>
  )
}
