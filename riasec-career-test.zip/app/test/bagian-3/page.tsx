"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { ArrowLeft, ArrowRight, Clock } from "lucide-react"
import { riasecQuestions } from "@/data/questions"
import { saveTestResult, type TestResult } from "@/utils/dataManager"

// Mock questions for Bagian III (70 questions, ~12 per RIASEC type)
const mockQuestions = riasecQuestions.bagian3.filter((q) => q.isActive)

export default function TestBagian3() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<{ [key: number]: string }>({})
  const [timeElapsed, setTimeElapsed] = useState(0)
  const router = useRouter()

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeElapsed((prev) => prev + 1)
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  const handleAnswer = (value: string) => {
    setAnswers((prev) => ({
      ...prev,
      [mockQuestions[currentQuestion].id]: value,
    }))
  }

  const handleNext = () => {
    if (currentQuestion < mockQuestions.length - 1) {
      setCurrentQuestion((prev) => prev + 1)
    } else {
      // Save Bagian III results and calculate final scores
      const bagian3Results = mockQuestions.reduce(
        (acc, question) => {
          const answer = answers[question.id]
          if (answer === "Y") {
            acc[question.type] = (acc[question.type] || 0) + 1
          }
          return acc
        },
        {} as { [key: string]: number },
      )

      localStorage.setItem("bagian3Results", JSON.stringify(bagian3Results))

      // Calculate total scores and save complete test result
      const bagian1 = JSON.parse(localStorage.getItem("bagian1Results") || "{}")
      const bagian2 = JSON.parse(localStorage.getItem("bagian2Results") || "{}")

      const totalScores = {
        R: (bagian1.R || 0) + (bagian2.R || 0) + (bagian3Results.R || 0),
        I: (bagian1.I || 0) + (bagian2.I || 0) + (bagian3Results.I || 0),
        A: (bagian1.A || 0) + (bagian2.A || 0) + (bagian3Results.A || 0),
        S: (bagian1.S || 0) + (bagian2.S || 0) + (bagian3Results.S || 0),
        E: (bagian1.E || 0) + (bagian2.E || 0) + (bagian3Results.E || 0),
        C: (bagian1.C || 0) + (bagian2.C || 0) + (bagian3Results.C || 0),
      }

      // Get top 3 dominant types
      const sortedTypes = Object.entries(totalScores)
        .sort(([, a], [, b]) => b - a)
        .slice(0, 3)
        .map(([type]) => type)

      // Get current user
      const userData = localStorage.getItem("user")
      const user = userData ? JSON.parse(userData) : null

      if (user) {
        const testResult: TestResult = {
          id: Date.now().toString(),
          userId: user.id,
          userName: user.fullName || user.name,
          userSchool: user.school || "",
          date: new Date().toISOString(),
          scores: totalScores,
          dominantTypes: sortedTypes,
          bagian1,
          bagian2,
          bagian3: bagian3Results,
        }

        saveTestResult(testResult)
      }

      // Clear temporary results
      localStorage.removeItem("bagian1Results")
      localStorage.removeItem("bagian2Results")
      localStorage.removeItem("bagian3Results")

      router.push("/dashboard/siswa/results")
    }
  }

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion((prev) => prev - 1)
    }
  }

  const progress = ((currentQuestion + 1) / mockQuestions.length) * 100
  const currentAnswer = answers[mockQuestions[currentQuestion].id]

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-rose-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <h1 className="text-lg font-semibold text-gray-900">Tes RIASEC - Bagian III</h1>
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Clock className="w-4 h-4" />
                <span>{formatTime(timeElapsed)}</span>
              </div>
            </div>
            <div className="text-sm text-gray-600">
              {currentQuestion + 1} dari {mockQuestions.length}
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Progress */}
        <div className="mb-8">
          <div className="flex justify-between text-sm text-gray-600 mb-2">
            <span>Progress Bagian III (Final)</span>
            <span>{Math.round(progress)}%</span>
          </div>
          <Progress value={progress} className="h-3" />
        </div>

        {/* Question Card */}
        <Card className="border-0 shadow-xl rounded-2xl mb-8">
          <CardHeader className="pb-6">
            <div className="flex items-center justify-between">
              <CardTitle className="text-xl">Pertanyaan {currentQuestion + 1}</CardTitle>
              <div className="px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm font-medium">
                Tipe: {mockQuestions[currentQuestion].type}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <p className="text-lg text-gray-900 leading-relaxed">{mockQuestions[currentQuestion].text}</p>

              <RadioGroup value={currentAnswer || ""} onValueChange={handleAnswer}>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center space-x-3 p-4 border-2 rounded-xl hover:bg-green-50 hover:border-green-300 transition-colors">
                    <RadioGroupItem value="Y" id="ya" />
                    <Label htmlFor="ya" className="flex-1 cursor-pointer font-medium text-green-700">
                      Ya (Y)
                    </Label>
                  </div>
                  <div className="flex items-center space-x-3 p-4 border-2 rounded-xl hover:bg-red-50 hover:border-red-300 transition-colors">
                    <RadioGroupItem value="T" id="tidak" />
                    <Label htmlFor="tidak" className="flex-1 cursor-pointer font-medium text-red-700">
                      Tidak (T)
                    </Label>
                  </div>
                </div>
              </RadioGroup>
            </div>
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentQuestion === 0}
            className="flex items-center space-x-2 bg-transparent"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Sebelumnya</span>
          </Button>

          <Button
            onClick={handleNext}
            disabled={!currentAnswer}
            className="flex items-center space-x-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
          >
            <span>{currentQuestion === mockQuestions.length - 1 ? "Selesai & Lihat Hasil" : "Selanjutnya"}</span>
            <ArrowRight className="w-4 h-4" />
          </Button>
        </div>

        {/* Instructions */}
        <div className="mt-8 p-4 bg-yellow-50 rounded-xl">
          <h4 className="font-semibold text-yellow-900 mb-2">Petunjuk:</h4>
          <ul className="text-sm text-yellow-800 space-y-1">
            <li>• Pilih "Ya (Y)" jika aktivitas tersebut menarik bagi Anda</li>
            <li>• Pilih "Tidak (T)" jika aktivitas tersebut tidak menarik bagi Anda</li>
            <li>• Ini adalah bagian terakhir dari tes RIASEC</li>
            <li>• Setelah selesai, Anda akan melihat hasil lengkap dengan grafik</li>
          </ul>
        </div>
      </div>
    </div>
  )
}
