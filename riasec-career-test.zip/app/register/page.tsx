"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ArrowLeft, GraduationCap } from "lucide-react"
import { saveUser, saveTeacher, type Teacher } from "@/utils/dataManager"
import type { User } from "@/utils/types" // Renamed to avoid redeclaration

export default function RegisterPage() {
  const [role, setRole] = useState("")
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    password: "",
    confirmPassword: "",
    dateOfBirth: "",
    school: "",
    phone: "",
  })
  const router = useRouter()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (formData.password !== formData.confirmPassword) {
      alert("Password tidak cocok!")
      return
    }

    const userId = Date.now().toString()
    const userData = {
      id: userId,
      name: formData.fullName,
      email: formData.email,
      role: role as "siswa" | "guru",
      school: formData.school,
      dateOfBirth: formData.dateOfBirth,
      phone: formData.phone,
      registrationDate: new Date().toISOString(),
      lastActive: new Date().toISOString(),
      approved: role === "siswa",
    }

    if (role === "siswa") {
      saveUser(userData as User)
      localStorage.setItem("user", JSON.stringify(userData))
      router.push("/dashboard/siswa")
    } else if (role === "guru") {
      const teacherData: Teacher = {
        ...userData,
        status: "pending",
      }
      saveTeacher(teacherData)
      router.push("/login?message=Akun guru menunggu persetujuan admin")
    }
  }

  const roleOptions = [
    { value: "siswa", label: "Siswa", icon: ArrowLeft, desc: "Ikuti tes RIASEC dan dapatkan hasil analisis karier" },
    { value: "guru", label: "Guru", icon: GraduationCap, desc: "Pantau hasil tes siswa dan buat laporan" },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="mb-6">
          <Link href="/" className="inline-flex items-center text-sm text-gray-600 hover:text-gray-900">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Kembali ke Beranda
          </Link>
        </div>

        <Card className="border-0 shadow-xl rounded-2xl">
          <CardHeader className="text-center pb-6">
            <CardTitle className="text-2xl font-bold">Daftar Akun</CardTitle>
            <CardDescription>Pilih peran dan lengkapi data diri</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Role Selection */}
              <div className="space-y-3">
                <Label>Pilih Peran</Label>
                <div className="grid gap-3">
                  {roleOptions.map((option) => (
                    <div
                      key={option.value}
                      className={`p-4 border-2 rounded-xl cursor-pointer transition-all ${
                        role === option.value ? "border-blue-500 bg-blue-50" : "border-gray-200 hover:border-gray-300"
                      }`}
                      onClick={() => setRole(option.value)}
                    >
                      <div className="flex items-start space-x-3">
                        <option.icon
                          className={`w-5 h-5 mt-0.5 ${role === option.value ? "text-blue-600" : "text-gray-400"}`}
                        />
                        <div>
                          <div className="font-medium">{option.label}</div>
                          <div className="text-sm text-gray-500">{option.desc}</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {role && (
                <>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="fullName">Nama Lengkap</Label>
                      <Input
                        id="fullName"
                        value={formData.fullName}
                        onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="dateOfBirth">Tanggal Lahir</Label>
                      <Input
                        id="dateOfBirth"
                        type="date"
                        value={formData.dateOfBirth}
                        onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })}
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      required
                    />
                  </div>

                  {(role === "siswa" || role === "guru") && (
                    <div>
                      <Label htmlFor="school">Sekolah</Label>
                      <Input
                        id="school"
                        value={formData.school}
                        onChange={(e) => setFormData({ ...formData, school: e.target.value })}
                        placeholder="Nama sekolah"
                        required
                      />
                    </div>
                  )}

                  <div>
                    <Label htmlFor="phone">No. Telepon</Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="08xxxxxxxxxx"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="password">Password</Label>
                      <Input
                        id="password"
                        type="password"
                        value={formData.password}
                        onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="confirmPassword">Konfirmasi Password</Label>
                      <Input
                        id="confirmPassword"
                        type="password"
                        value={formData.confirmPassword}
                        onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                        required
                      />
                    </div>
                  </div>

                  <Button type="submit" className="w-full rounded-xl">
                    Daftar Sekarang
                  </Button>
                </>
              )}
            </form>

            <div className="mt-6 text-center">
              <p className="text-sm text-gray-600">
                Sudah punya akun?{" "}
                <Link href="/login" className="text-blue-600 hover:underline">
                  Masuk di sini
                </Link>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
